package menu;

import railwaystation.RailwayStation;
import railwaystation.RailwayStationConnection;
import railwaystation.RailwayStationNetwork;
import trainset.Trainset;
import trainset.locomotive.Locomotive;
import trainset.railroadcar.RailroadCar;

import java.util.*;

public class ObjectRemover {
    private Scanner scanner;
    private List<Trainset> trainsets;
    private Map<Integer, RailroadCar> railroadCars;
    private RailwayStationNetwork railwayStationNetwork;


    public ObjectRemover(Scanner scanner, List<Trainset> trainsets, Map<Integer, RailroadCar> railroadCars, RailwayStationNetwork railwayStationNetwork) {
        this.scanner = scanner;
        this.trainsets = trainsets;
        this.railroadCars = railroadCars;
        this.railwayStationNetwork = railwayStationNetwork;
    }

    public void handleRemoveObject() {
        System.out.println("Which object would you like to remove?");
        System.out.println("1. Locomotive");
        System.out.println("2. Railroad Car");
        System.out.println("3. Railway Station");
        System.out.println("4. Connection between Railway Stations");

        int objectType = readIntInput(1,4);

        switch (objectType) {
            case 1:
                removeLocomotive();
                break;
            case 2:
                removeRailroadCar();
                break;
            case 3:
                removeRailwayStation();
                break;
            case 4:
                removeConnection();
                break;
        }
    }

    private void removeLocomotive() {
        System.out.println("Enter the ID of the locomotive you want to remove: ");
        int locomotiveId = readIntInput(0,Integer.MAX_VALUE);

        Trainset trainsetToRemove = null;
        for (Trainset trainset : trainsets) {
            if (trainset.getLocomotive().getId() == locomotiveId) {
                trainsetToRemove = trainset;
                break;
            }
        }

        if (trainsetToRemove != null) {
            trainsets.remove(trainsetToRemove);
            System.out.println("Locomotive with ID " + locomotiveId + " removed");
        } else {
            System.out.println("ERROR: Locomotive not found");
        }
    }

    private Locomotive findLocomotiveById (int id) {
        for (Trainset trainset : trainsets) {
            Locomotive locomotive = trainset.getLocomotive();
            System.out.println("Checking locomotive with ID " + locomotive.getId());
            if (locomotive.getId() == id) {
                System.out.println("Locomotive with ID" + id + " found in the trainset");
                return locomotive;
            }
        }
        System.out.println("hmm");
        return null;
    }

    private void removeRailroadCar() {
        System.out.println("Enter the ID of the railroad car you want to remove: ");
        int ralroadCarId = readIntInput(0,Integer.MAX_VALUE);

        Trainset trainsetContainingCar = null;
        RailroadCar carToRemove = null;

        for (Trainset trainset : trainsets) {
            RailroadCar car = trainset.findCarById(ralroadCarId);
            if (car != null) {
                trainsetContainingCar = trainset;
                carToRemove = car;
                break;
            }
        }

        if (trainsetContainingCar != null && carToRemove != null) {
            trainsetContainingCar.removeRailroadCar(ralroadCarId);
            System.out.println("Railroad car with ID " + ralroadCarId + " removed");
        } else {
            System.out.println("ERROR: Railroad car not found");
        }
    }

    private void removeRailwayStation() {
        System.out.println("Enter the ID of the railway station you want to remove: ");
        int stationId = readIntInput(0,Integer.MAX_VALUE);

        RailwayStation stationToRemove = railwayStationNetwork.getStationById(stationId);
        if (stationToRemove != null) {
            for (RailwayStationConnection connection : new ArrayList<>(stationToRemove.getConnections())) {
                stationToRemove.removeConnection(connection);
                railwayStationNetwork.getStations().remove(connection);
            }

            railwayStationNetwork.getStations().remove(stationId);
            System.out.println("Railway station with ID " + stationId + " removed");
        } else {
            System.out.println("ERROR: Railway station not found");
        }
    }

    private void removeConnection() {
        System.out.println("Please enter the ID of the first railway station:");
        int firstId = readIntInput(0, Integer.MAX_VALUE);
        RailwayStation firstStation = railwayStationNetwork.getStationById(firstId);

        System.out.println("Please enter the ID of the second railway station:");
        int secondId = readIntInput(0, Integer.MAX_VALUE);
        RailwayStation secondStation = railwayStationNetwork.getStationById(secondId);

        if (firstStation != null && secondStation != null) {
            RailwayStationConnection connectionToRemove = null;
            for (RailwayStationConnection connection : firstStation.getConnections()) {
                if (connection.getDestination().equals(secondStation)) {
                    connectionToRemove = connection;
                    break;
                }
            }

            if (connectionToRemove != null) {
                firstStation.removeConnection(connectionToRemove);
                railwayStationNetwork.getConnections().remove(connectionToRemove);
                System.out.println("Connection between railway stations with IDs " + firstId + " and " + secondId + " removed");
            } else {
                System.out.println("ERROR: Connection not found");
            }
        } else {
            System.out.println("ERROR: Railway stations not found");
        }
    }


    private int readIntInput(int min, int max) {
        int choice = -1;
        while (choice < min || choice > max) {
            try {
                //System.out.println("Enter your choice: ");
                choice = scanner.nextInt();
                if (choice < min || choice > max) {
                    System.out.println("ERROR: Please enter a number between " + min + " and " + max + ".");
                }
            } catch (InputMismatchException e) {
                System.out.println("ERROR: Please enter a number.");
                scanner.next();
            }
        }
        return choice;
    }
}
