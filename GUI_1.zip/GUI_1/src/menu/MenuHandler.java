package menu;

import java.util.InputMismatchException;
import java.util.Scanner;

public class MenuHandler {
    private Scanner scanner;

    public MenuHandler() {
        this.scanner = new Scanner(System.in);
    }

    public void printMenu() {
        System.out.println("\nAvailable options:");
        System.out.println("1. Create a new locomotive");
        System.out.println("2. Create a new railroad car");
        System.out.println("3. Create a new railway station");
        System.out.println("4. Create a new connection between railway stations");
        System.out.println("5. Perform a special action of a railroad car");
        System.out.println("6. Remove an object");
        System.out.println("7. Display a trainset report by ID");
        System.out.println("8. Display all trainsets");
        System.out.println("9. Display all railway stations");
        System.out.println("10. Exit\n");
    }

    public int getUserChoice() {
        System.out.println("Please enter your choice (1-11)");
        int choice = readIntInput(1,10);
        return choice;
    }

    private int readIntInput(int min, int max) {
        int choice = -1;
        while (choice < min || choice > max) {
            try {
                //System.out.println("Enter your choice: ");
                choice = scanner.nextInt();
                if (choice < min || choice > max) {
                    System.out.println("ERROR: Please enter a number between " + min + " and " + max + ".");
                }
            } catch (InputMismatchException e) {
                System.out.println("ERROR: Please enter a number.");
                scanner.next();
            }
        }
        return choice;
    }
}
