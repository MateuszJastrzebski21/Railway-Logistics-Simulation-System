package menu;

import railwaystation.RailwayStation;
import railwaystation.RailwayStationNetwork;
import trainset.Trainset;
import trainset.locomotive.Locomotive;
import trainset.railroadcar.RailroadCar;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

public class LocomotiveCreator {
    private List<Locomotive> locomotives;
    private List<Trainset> trainsets;
    private RailwayStationNetwork railwayStationNetwork;
    private Scanner scanner;

    public LocomotiveCreator(RailwayStationNetwork railwayStationNetwork) {
        this.locomotives = new ArrayList<>();
        this.trainsets = new ArrayList<>();
        this.railwayStationNetwork = railwayStationNetwork;
        this.scanner = new Scanner(System.in);
    }

    public Locomotive createNewLocomotive() {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter the name of the locomotive: ");
        String name = scanner.nextLine();

        System.out.println("Enter the maximum number of railroad cars: ");
        int maxNumOfCars = readIntInput(0, Integer.MAX_VALUE);

        System.out.println("Enter the maximum weight of the transported load in kg: ");
        int maxWeightOfLoad = readIntInput(0, Integer.MAX_VALUE);

        System.out.println("Enter the maximum number of railroad cars that need a connection to the electricity grid: ");
        int maxNumOfCarsConnected = readIntInput(0, Integer.MAX_VALUE);

        System.out.println("Enter the locomotive's speed: ");
        double speed = scanner.nextDouble();

        System.out.println("Enter the home station name: ");
        String homeStationName = scanner.nextLine();

        System.out.println("Enter the source station name: ");
        String sourceStationName = scanner.nextLine();

        System.out.println("Enter the destination station name: ");
        String destinationStationName = scanner.nextLine();

        RailwayStation sourceStation = railwayStationNetwork.getStationByName(sourceStationName);
        RailwayStation homeStation = railwayStationNetwork.getStationByName(homeStationName);
        RailwayStation destinationStation = railwayStationNetwork.getStationByName(destinationStationName);

        //System.out.println("Home station name entered: " + homeStationName);
        //System.out.println("Source station name entered: " + sourceStationName);
        //System.out.println("Destination station name entered: " + destinationStationName);

        /*if (sourceStation == null) {
            System.out.println("ERROR: Source station not found: " + sourceStationName);
            //return null;
        }

        if (homeStation == null) {
            System.out.println("ERROR: Home station not found: " + homeStationName);
            //return null;
        }


        if (destinationStation == null) {
            System.out.println("ERROR: Destination station not found: " + destinationStationName);
            //return null;
        }*/

        Locomotive locomotive = new Locomotive(maxNumOfCars, maxWeightOfLoad, maxNumOfCarsConnected, name, homeStation, sourceStation, destinationStation, speed);
        locomotives.add(locomotive);


        Trainset trainset = new Trainset(locomotive);
        trainsets.add(trainset);

        System.out.println("Locomotive created, ID: " + locomotive.getId());
        return locomotive;
    }

    public Trainset createNewTrainset(Locomotive locomotive) {
        List<RailroadCar> emptyRailroadCars = new ArrayList<>();
        RailwayStation homeStation = locomotive.getHomeStation();
        RailwayStation sourceStation = locomotive.getSourceStation();
        RailwayStation destinationStation = locomotive.getDestinationStation();
        Trainset trainset = new Trainset(locomotive);
        trainsets.add(trainset);
        return trainset;
    }

    private int readIntInput(int min, int max) {
        int choice = -1;
        while (choice < min || choice > max) {
            try {
                //System.out.println("Enter your choice: ");
                choice = scanner.nextInt();
                if (choice < min || choice > max) {
                    System.out.println("ERROR: Please enter a number between " + min + " and " + max + ".");
                }
            } catch (InputMismatchException e) {
                System.out.println("ERROR: Please enter a number.");
                scanner.next();
            }
        }
        return choice;
    }

}
