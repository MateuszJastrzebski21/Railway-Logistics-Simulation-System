package menu;

import railwaystation.RailwayStation;
import trainset.Trainset;
import trainset.railroadcar.RailroadCar;
import trainset.railroadcar.baggageandmail.BaggageAndMailRailroadCar;
import trainset.railroadcar.freight.basicfreight.BasicFreightRailroadCar;
import trainset.railroadcar.freight.basicfreight.gaseousmaterials.GaseousMaterialsRailroadCar;
import trainset.railroadcar.freight.basicfreight.liquidmaterials.LiquidMaterialsRailroadCar;
import trainset.railroadcar.freight.basicfreight.refrigerated.RefrigeratedRailroadCar;
import trainset.railroadcar.freight.heavyfreight.HeavyFreightRailroadCar;
import trainset.railroadcar.freight.heavyfreight.explosives.ExplosivesRailroadCar;
import trainset.railroadcar.freight.heavyfreight.toxicmaterials.ToxicMaterialsRailroadCar;
import trainset.railroadcar.freight.heavyfreight.toxicmaterials.liquidtoxicmaterial.LiquidToxicMaterialRailroadCar;
import trainset.railroadcar.passenger.PassengerRailroadCar;
import trainset.railroadcar.postoffice.PostOfficeRailroad;
import trainset.railroadcar.restaurant.RestaurantRailroadCar;

import java.util.InputMismatchException;
import java.util.Map;
import java.util.Scanner;

public class SpecialActionHandler {
    private RailroadCar car;
    private Scanner scanner;

    public SpecialActionHandler(RailroadCar car, Scanner scanner) {
        this.car = car;
        this.scanner = scanner;
    }

    public void handleSpecialAction(int id) {
        if (car instanceof PassengerRailroadCar) {
            handlePassengerRailroadCarActions();
        } else if (car instanceof PostOfficeRailroad) {
            handlePostOfficeRailroadCarActions();
        } else if (car instanceof BaggageAndMailRailroadCar) {
            handleBaggageAndMailCarActions();
        } else if (car instanceof RestaurantRailroadCar) {
            handleRestaurantCarActions();
        } else if (car instanceof RefrigeratedRailroadCar) {
            handleRefrigeratedCarActions();
        } else if (car instanceof LiquidToxicMaterialRailroadCar) {
            handleLiquidToxicMaterialCarActions();
        } else if (car instanceof LiquidMaterialsRailroadCar) {
            handleLiquidMaterialsCarActions();
        } else if (car instanceof GaseousMaterialsRailroadCar) {
            handleGaseousMaterialsCarActions();
        } else if (car instanceof ExplosivesRailroadCar) {
            handleExplosivesCarActions();
        } else if (car instanceof ToxicMaterialsRailroadCar) {
            handleToxicMaterialsCarActions();
        } else if (car instanceof BasicFreightRailroadCar) {
            handleBasicFreightCarActions();
        } else if (car instanceof HeavyFreightRailroadCar) {
            handleHeavyFreightCarActions();
        } else {
            System.out.println("Unknown type ");
        }
    }

    private void handlePassengerRailroadCarActions() {
        PassengerRailroadCar passengerRailroadCar = (PassengerRailroadCar) car;
        System.out.println("1. Load passengers");
        System.out.println("2. Unload passengers");
        System.out.println("3. Adjust lights");
        System.out.println("4. Change connection to the electrical grid");
        int choice = readIntInput(1,4);
        switch (choice) {
            case 1:
                if (isAtStation(passengerRailroadCar)){
                    System.out.println("Enter the number of passengers to load: ");
                    int passengersToLoad = readIntInput(0, Integer.MAX_VALUE);
                    passengerRailroadCar.loadPassengers(passengersToLoad);
                } else {
                    System.out.println("ERROR: The railroad car is moving!");
                }
                break;
            case 2:
                System.out.println("Enter the number of passengers to unload: ");
                int passengersToUnload = readIntInput(0, Integer.MAX_VALUE);
                passengerRailroadCar.unloadPassengers(passengersToUnload);
                break;
            case 3:
                passengerRailroadCar.adjustLights();
            case 4:
                passengerRailroadCar.changeConnection();
            default:
                System.out.println("Invalid choice");
        }
    }

    private void handlePostOfficeRailroadCarActions() {
        PostOfficeRailroad postOfficeRailroad = (PostOfficeRailroad) car;
        System.out.println("1. Deliver mail");
        System.out.println("2. Sort mail");
        System.out.println("3. Change connection to the electrical grid");
        int choice = readIntInput(1,3);
        switch (choice) {
            case 1:
                if (isAtStation(postOfficeRailroad)) {
                    postOfficeRailroad.deliverMail();
                } else {
                    System.out.println("ERROR: The railroad car is moving!");
                }
                break;
            case 2:
                postOfficeRailroad.sortMail();
                break;
            case 3:
                postOfficeRailroad.changeConnection();
                break;
            default:
                System.out.println("Invalid choice");
        }
    }

    private void handleBaggageAndMailCarActions() {
        BaggageAndMailRailroadCar baggageAndMailRailroadCar = (BaggageAndMailRailroadCar) car;
        System.out.println("1. Load the baggage");
        System.out.println("2. Unload the baggage");
        int choice = readIntInput(1,2);
        switch (choice) {
            case 1:
                if (isAtStation(baggageAndMailRailroadCar)) {
                    baggageAndMailRailroadCar.loadBaggage();
                } else {
                    System.out.println("ERROR: The railroad car is moving!");
                }
                break;
            case 2:
                if (isAtStation(baggageAndMailRailroadCar)) {
                    baggageAndMailRailroadCar.unloadBaggage();
                } else {
                    System.out.println("ERROR: The railroad car is moving!");
                }
                break;
            default:
                System.out.println("Invalid choice");
        }
    }

    private void handleRestaurantCarActions() {
        RestaurantRailroadCar restaurantRailroadCar = (RestaurantRailroadCar) car;
        System.out.println("1. Serve food");
        System.out.println("2. Serve a drink");
        System.out.println("3. Change connection to the electrical grid");
        int choice = readIntInput(1,3);
        switch (choice) {
            case 1:
                restaurantRailroadCar.serveFood();
                break;
            case 2:
                restaurantRailroadCar.serveDrink();
                break;
            case 3:
                restaurantRailroadCar.changeConnection();
                break;
            default:
                System.out.println("Invalid choice");
        }
    }

    private void handleRefrigeratedCarActions() {
        RefrigeratedRailroadCar refrigeratedRailroadCar = (RefrigeratedRailroadCar) car;
        System.out.println("1. Load the cargo");
        System.out.println("2. Unload the cargo");
        System.out.println("3. Increase the temperature");
        System.out.println("4. Lower the temperature");
        System.out.println("5. Change connection to the electrical grid");
        int choice = readIntInput(1,5);
        switch (choice) {
            case 1:
                System.out.println("Enter how many cubic meters of cargo to load: ");
                int cargoToLoad = readIntInput(0, Integer.MAX_VALUE);
                refrigeratedRailroadCar.loadCargo(cargoToLoad);
                break;
            case 2:
                System.out.println("Enter how many cubic meters of cargo to unload: ");
                int cargoToUnload = readIntInput(0, Integer.MAX_VALUE);
                refrigeratedRailroadCar.unloadCargo(cargoToUnload);
                break;
            case 3:
                System.out.println("Enter by how many degrees Celcius: ");
                int tempToIncrease = readIntInput(0, Integer.MAX_VALUE);
                refrigeratedRailroadCar.increseTemperature(tempToIncrease);
                break;
            case 4:
                System.out.println("Enter by how many degrees Celcius: ");
                int tempToLower = readIntInput(0, Integer.MAX_VALUE);
                refrigeratedRailroadCar.lowerTemperature(tempToLower);
                break;
            case 5:
                refrigeratedRailroadCar.changeConnection();
                break;
            default:
                System.out.println("Invalid choice");
        }
    }

    private void handleLiquidToxicMaterialCarActions() {
        LiquidToxicMaterialRailroadCar liquidToxicMaterialRailroadCar= (LiquidToxicMaterialRailroadCar) car;
        System.out.println("1. Clean cargo area");
        System.out.println("2. Inspect the cargo");
        System.out.println("3. - Decontaminate");
        System.out.println("4 - Display warnings");
        System.out.println("5. - Monitor the tank for corrosion");
        System.out.println("6 - Analyze the chemical composition");
        System.out.println("7 - Control the pH of the fluid");
        System.out.println("8 - Track cargo");
        int choice = readIntInput(1,8);
        switch (choice) {
            case 1:
                if (isAtStation(liquidToxicMaterialRailroadCar)) {
                    liquidToxicMaterialRailroadCar.cleanCargoArea();
                } else {
                    System.out.println("ERROR: The railroad car is moving!");
                }
                break;
            case 2:
                if (isAtStation(liquidToxicMaterialRailroadCar)) {
                    liquidToxicMaterialRailroadCar.inspectTheCargo();
                } else {
                    System.out.println("ERROR: The railroad car is moving!");
                }
                break;
            case 3:
                if (isAtStation(liquidToxicMaterialRailroadCar)) {
                    liquidToxicMaterialRailroadCar.decontaminate();
                } else {
                    System.out.println("ERROR: The railroad car is moving!");
                }
                break;
            case 4:
                liquidToxicMaterialRailroadCar.displayWarnings();
                break;
            case 5:
                liquidToxicMaterialRailroadCar.corrosionMonitor();
                break;
            case 6:
                liquidToxicMaterialRailroadCar.analyzeChemicalComposition();
                break;
            case 7:
                liquidToxicMaterialRailroadCar.controlPh();
                break;
            case 8:
                liquidToxicMaterialRailroadCar.trackCargo();
                break;
            default:
                System.out.println("Invalid choice");
        }
    }

    private void handleLiquidMaterialsCarActions() {
        LiquidMaterialsRailroadCar liquidMaterialsRailroadCar= (LiquidMaterialsRailroadCar) car;
        System.out.println("1. Load the cargo");
        System.out.println("2. Unload the cargo");
        System.out.println("3. - Monitor the tank for corrosion");
        System.out.println("4 - Analyze the chemical composition");
        int choice = readIntInput(1,4);
        switch (choice) {
            case 1:
                System.out.println("Enter how many cubic meters of cargo to load: ");
                int cargoToLoad = readIntInput(0, Integer.MAX_VALUE);
                liquidMaterialsRailroadCar.loadCargo(cargoToLoad);
                break;
            case 2:
                System.out.println("Enter how many cubic meters of cargo to unload: ");
                int cargoToUnload = readIntInput(0, Integer.MAX_VALUE);
                liquidMaterialsRailroadCar.unloadCargo(cargoToUnload);
                break;
            case 3:
                liquidMaterialsRailroadCar.corrosionMonitor();
                break;
            case 4:
                liquidMaterialsRailroadCar.analyzeChemicalComposition();
            default:
                System.out.println("Invalid choice");
        }
    }

    private void handleGaseousMaterialsCarActions() {
        GaseousMaterialsRailroadCar gaseousMaterialsRailroadCar= (GaseousMaterialsRailroadCar) car;
        System.out.println("1. Load the cargo");
        System.out.println("2. Unload the cargo");
        System.out.println("3. - Ventilate");
        System.out.println("4 - Detect gas leaks");
        int choice = readIntInput(1,4);
        switch (choice) {
            case 1:
                System.out.println("Enter how many cubic meters of cargo to load: ");
                int cargoToLoad = readIntInput(0, Integer.MAX_VALUE);
                gaseousMaterialsRailroadCar.loadCargo(cargoToLoad);
                break;
            case 2:
                System.out.println("Enter how many cubic meters of cargo to unload: ");
                int cargoToUnload = readIntInput(0, Integer.MAX_VALUE);
                gaseousMaterialsRailroadCar.unloadCargo(cargoToUnload);
                break;
            case 3:
                gaseousMaterialsRailroadCar.ventilate();
                break;
            case 4:
                gaseousMaterialsRailroadCar.detectGasLeak();
                break;
            default:
                System.out.println("Invalid choice");
        }
    }

    private void handleExplosivesCarActions() {
        ExplosivesRailroadCar explosivesRailroadCar= (ExplosivesRailroadCar) car;
        System.out.println("1. Clean cargo area");
        System.out.println("2. Inspect the cargo");
        System.out.println("3. Initiate explosives emergency");
        System.out.println("4. Detonate");
        int choice = readIntInput(1,4);
        switch (choice) {
            case 1:
                if (isAtStation(explosivesRailroadCar)) {
                    explosivesRailroadCar.cleanCargoArea();
                } else {
                    System.out.println("ERROR: The railroad car is moving!");
                }
                break;
            case 2:
                if (isAtStation(explosivesRailroadCar)) {
                    explosivesRailroadCar.inspectTheCargo();
                } else {
                    System.out.println("ERROR: The railroad car is moving!");
                }
                break;
            case 3:
                explosivesRailroadCar.explosivesEmergency();
                break;
            case 4:
                System.out.println("Are you sure? (Kaboom?) (1 - Yes, 2 - No");
                int decision = readIntInput(1,2);
                if (decision == 1) {
                    explosivesRailroadCar.detonate();
                } else {
                    System.out.println("Aborting the detonation...");
                }
                break;
            default:
                System.out.println("Invalid choice");
        }
    }

    private void handleToxicMaterialsCarActions() {
        ToxicMaterialsRailroadCar toxicMaterialsRailroadCar= (ToxicMaterialsRailroadCar) car;
        System.out.println("1. Clean cargo area");
        System.out.println("2. Inspect the cargo");
        System.out.println("3. Decontaminate toxic materials");
        System.out.println("4. Display warnings");
        int choice = readIntInput(1,4);
        switch (choice) {
            case 1:
                if (isAtStation(toxicMaterialsRailroadCar)) {
                    toxicMaterialsRailroadCar.cleanCargoArea();
                } else {
                    System.out.println("ERROR: The railroad car is moving!");
                }
                break;
            case 2:
                if (isAtStation(toxicMaterialsRailroadCar)) {
                    toxicMaterialsRailroadCar.inspectTheCargo();
                } else {
                    System.out.println("ERROR: The railroad car is moving!");
                }
                break;
            case 3:
                if (isAtStation(toxicMaterialsRailroadCar)) {
                    toxicMaterialsRailroadCar.decontaminate();
                } else {
                    System.out.println("ERROR: The railroad car is moving!");
                }
                break;
            case 4:
                toxicMaterialsRailroadCar.displayWarnings();
            default:
                System.out.println("Invalid choice");
        }
    }

    private void handleBasicFreightCarActions() {
        BasicFreightRailroadCar basicFreightRailroadCar= (BasicFreightRailroadCar) car;
        System.out.println("1. Load the cargo");
        System.out.println("2. Unload the cargo");
        int choice = readIntInput(1,2);
        switch (choice) {
            case 1:
                System.out.println("Enter how many cubic meters of cargo to load: ");
                int cargoToLoad = readIntInput(0, Integer.MAX_VALUE);
                basicFreightRailroadCar.loadCargo(cargoToLoad);
                break;
            case 2:
                System.out.println("Enter how many cubic meters of cargo to unload: ");
                int cargoToUnload = readIntInput(0, Integer.MAX_VALUE);
                basicFreightRailroadCar.unloadCargo(cargoToUnload);
                break;
            default:
                System.out.println("Invalid choice");
        }
    }

    private void handleHeavyFreightCarActions() {
        HeavyFreightRailroadCar heavyFreightRailroadCar= (HeavyFreightRailroadCar) car;
        System.out.println("1. Clean cargo area");
        System.out.println("2. Inspect the cargo");
        int choice = readIntInput(1,2);
        switch (choice) {
            case 1:
                if (isAtStation(heavyFreightRailroadCar)) {
                    heavyFreightRailroadCar.cleanCargoArea();
                } else {
                    System.out.println("ERROR: The railroad car is moving!");
                }
                break;
            case 2:
                if (isAtStation(heavyFreightRailroadCar)) {
                    heavyFreightRailroadCar.inspectTheCargo();
                } else {
                    System.out.println("ERROR: The railroad car is moving!");
                }
                break;
            default:
                System.out.println("Invalid choice");
        }
    }

    private int readIntInput(int min, int max) {
        int choice = -1;
        while (choice < min || choice > max) {
            try {
                System.out.println("Enter your choice: ");
                choice = scanner.nextInt();
                if (choice < min || choice > max) {
                    System.out.println("ERROR: Please enter a number between " + min + " and " + max + ".");
                }
            } catch (InputMismatchException e) {
                System.out.println("ERROR: Please enter a number.");
                scanner.next();
            }
        }
        return choice;
    }

    private boolean isAtStation(RailroadCar car) {
        Trainset trainset = car.getTrainset();
        if (trainset != null) {
            RailwayStation curentStation = trainset.getLocomotive().getCurrentStation();
            return curentStation != null;
        }
        return false;
    }
}

