package menu;

import trainset.Trainset;
import trainset.railroadcar.RailroadCar;
import trainset.railroadcar.baggageandmail.BaggageAndMailRailroadCar;
import trainset.railroadcar.baggageandmail.BaggageHandlingMechanism;
import trainset.railroadcar.freight.SecurityInformation;
import trainset.railroadcar.freight.Shipper;
import trainset.railroadcar.freight.basicfreight.BasicFreightRailroadCar;
import trainset.railroadcar.freight.basicfreight.gaseousmaterials.GasType;
import trainset.railroadcar.freight.basicfreight.gaseousmaterials.GaseousMaterialsRailroadCar;
import trainset.railroadcar.freight.basicfreight.liquidmaterials.LiquidMaterialsRailroadCar;
import trainset.railroadcar.freight.basicfreight.liquidmaterials.PumpType;
import trainset.railroadcar.freight.basicfreight.liquidmaterials.TankMaterial;
import trainset.railroadcar.freight.basicfreight.refrigerated.RefrigeratedRailroadCar;
import trainset.railroadcar.freight.heavyfreight.BrakeSystem;
import trainset.railroadcar.freight.heavyfreight.HeavyFreightRailroadCar;
import trainset.railroadcar.freight.heavyfreight.explosives.ExplosiveType;
import trainset.railroadcar.freight.heavyfreight.explosives.ExplosivesRailroadCar;
import trainset.railroadcar.freight.heavyfreight.explosives.LockingMechanism;
import trainset.railroadcar.freight.heavyfreight.toxicmaterials.HazmatSuit;
import trainset.railroadcar.freight.heavyfreight.toxicmaterials.ToxicMaterialsRailroadCar;
import trainset.railroadcar.freight.heavyfreight.toxicmaterials.liquidtoxicmaterial.LiquidToxicMaterialRailroadCar;
import trainset.railroadcar.passenger.PassengerRailroadCar;
import trainset.railroadcar.passenger.SeatType;
import trainset.railroadcar.postoffice.PostOfficeRailroad;
import trainset.railroadcar.restaurant.CuisineType;
import trainset.railroadcar.restaurant.RestaurantRailroadCar;

import java.util.*;

public class RailroadCarCreator {
    private int nextRailroadCarId;
    private Map<Integer, RailroadCar> railroadCars;
    private Scanner scanner;

    public RailroadCarCreator() {
        this.nextRailroadCarId = 1;
        this.railroadCars = new HashMap<>();
        this.scanner = new Scanner(System.in);
    }

    public int getNextRailroadCarId() {
        return nextRailroadCarId++;
    }

    public Map<Integer, RailroadCar> getRailroadCars() {
        return railroadCars;
    }

    public void createNewRailroadCar(List<Trainset> trainsets) {
        System.out.println("Enter the ID of the trainset to which the railroad car should be attached: ");
        int trainsetId = readIntInput(0, Integer.MAX_VALUE);
        Trainset trainset = null;

        for (Trainset t : trainsets) {
            if (t.getLocomotive().getId() == trainsetId) {
                trainset = t;
                break;
            }
        }

        if (trainset == null) {
            System.out.println("ERROR: Trainset not found");
            return;
        }

        System.out.println("Enter the railroad car type:");
        System.out.println("1 - Passenger");
        System.out.println("2 - Post office");
        System.out.println("3 - Baggage and mail");
        System.out.println("4 - Restaurant");
        System.out.println("5 - Basic freight");
        System.out.println("6 - Heavy freight");
        System.out.println("7 - Refrigerated");
        System.out.println("8 - Liquid materials");
        System.out.println("9 - Gaseous materials");
        System.out.println("10 - Explosives");
        System.out.println("11 - Toxic material");
        System.out.println("12 - Liquid toxic material");

        int carType = readIntInput(1, 12);

        if (carType == 1) {
            createAndAttachPassengerRailroadCar(trainsets, trainset);
        } else if (carType == 2) {
            createAndAttachPostOfficeRailroadCar(trainsets, trainset);
        } else if (carType == 3) {
            createAndAttachBaggageAndMailCar(trainsets, trainset);
        } else if (carType == 4) {
            createAndAttachRestaurantCar(trainsets, trainset);
        } else if (carType == 5) {
            createAndAttachBasicFreightCar(trainsets, trainset);
        } else if (carType == 6) {
            createAndAttachHeavyFreightCar(trainsets, trainset);
        } else if (carType == 7) {
            createAndAttachRefrigeratedCar(trainsets, trainset);
        } else if (carType == 8) {
            createAndAttachLiquidMaterialsCar(trainsets, trainset);
        } else if (carType == 9) {
            createAndAttachGaseousMaterialsCar(trainsets, trainset);
        } else if (carType == 10) {
            createAndAttachExplosivesCar(trainsets, trainset);
        } else if (carType == 11) {
            createAndAttachToxicMaterialCar(trainsets, trainset);
        } else {
            createAndAttachLiquidToxicMaterialCar(trainsets, trainset);
        }
    }


    private void createAndAttachPassengerRailroadCar(List<Trainset> trainsets, Trainset trainset) {
        System.out.println("Enter the net weight of the car: ");
        int netWeight = readIntInput(0, Integer.MAX_VALUE);
        System.out.println("Enter tne gross weight of the car: ");
        int grossWeight = readIntInput(0, Integer.MAX_VALUE);
        System.out.println("Enter the number of passengers: ");
        int numOfPassengers = readIntInput(0, Integer.MAX_VALUE);
        System.out.println("Enter the number of seats: ");
        int numOfSeats = readIntInput(0, Integer.MAX_VALUE);
        System.out.println("Enter the seat type");
        System.out.println("1 - First Class");
        System.out.println("2 - Business Class");
        System.out.println("3 - Economy Class");
        int seatTypeChoice = readIntInput(1, 3);
        SeatType seatType = null;

        switch (seatTypeChoice) {
            case 1:
                seatType = SeatType.FIRST_CLASS;
                break;
            case 2:
                seatType = SeatType.BUSINESS_CLASS;
                break;
            case 3:
                seatType = SeatType.ECONOMY_CLASS;
                break;
            default:
                System.out.println("ERROR: Invalid choice");
                return;
        }

        System.out.println("Is the railroad car connected to the electrical grid? (1 - Yes, 2 - No)");
        int connectedToGrid = readIntInput(1,2);
        boolean isConnectedToGrid = connectedToGrid == 1;

        scanner.nextLine();

        int railroadCarId = getNextRailroadCarId();
        PassengerRailroadCar passengerRailroadCar = new PassengerRailroadCar(netWeight, grossWeight, numOfPassengers, numOfSeats, seatType, isConnectedToGrid);
        railroadCars.put(railroadCarId, passengerRailroadCar);

        if (isLightEnough(trainset, grossWeight, passengerRailroadCar)) {
            railroadCars.put(railroadCarId, passengerRailroadCar);
        }
    }

    private void createAndAttachPostOfficeRailroadCar(List<Trainset> trainsets, Trainset trainset) {
        System.out.println("Enter the net weight of the car: ");
        int netWeight = readIntInput(0, Integer.MAX_VALUE);

        System.out.println("Enter tne gross weight of the car: ");
        int grossWeight = readIntInput(0, Integer.MAX_VALUE);

        System.out.println("Enter tne number of mail slots: ");
        int numberOfMailSlots = readIntInput(0, Integer.MAX_VALUE);

        System.out.println("Does the railroad car have a sorting machine? (1 - Yes, 2 - No)");
        int sortningMachine = readIntInput(1,2);
        boolean hasSortingMachine = sortningMachine == 1;

        System.out.println("Is the railroad car connected to the electrical grid? (1 - Yes, 2 - No)");
        int connectedToGrid = readIntInput(1,2);
        boolean isConnectedToGrid = connectedToGrid == 1;

        scanner.nextLine();

        int railroadCarId = getNextRailroadCarId();
        PostOfficeRailroad postOfficeRailroad = new PostOfficeRailroad(netWeight, grossWeight, numberOfMailSlots, hasSortingMachine, isConnectedToGrid);
        railroadCars.put(railroadCarId, postOfficeRailroad);

        if (isLightEnough(trainset, grossWeight, postOfficeRailroad)) {
            railroadCars.put(railroadCarId, postOfficeRailroad);
        }
    }

    private void createAndAttachBaggageAndMailCar(List<Trainset> trainsets, Trainset trainset) {
        System.out.println("Enter the net weight of the car: ");
        int netWeight = readIntInput(0, Integer.MAX_VALUE);

        System.out.println("Enter tne gross weight of the car: ");
        int grossWeight = readIntInput(0, Integer.MAX_VALUE);

        System.out.println("Enter tne max amount of baggage items: ");
        int maxBaggageItems = readIntInput(0, Integer.MAX_VALUE);

        System.out.println("Enter the type of baggage handling mechanism");
        System.out.println("1 - Robotic");
        System.out.println("2 - Conveyor");
        System.out.println("3 - Manual");
        int baggageHandlingMechanismChoice = readIntInput(1, 3);
        BaggageHandlingMechanism baggageHandlingMechanism = null;
        switch (baggageHandlingMechanismChoice) {
            case 1:
                baggageHandlingMechanism = BaggageHandlingMechanism.ROBOTIC;
                break;
            case 2:
                baggageHandlingMechanism = BaggageHandlingMechanism.CONVEYOR;
                break;
            case 3:
                baggageHandlingMechanism = BaggageHandlingMechanism.MANUAL;
                break;
            default:
                System.out.println("ERROR: Invalid choice");
                return;
        }

        scanner.nextLine();

        int railroadCarId = getNextRailroadCarId();
        BaggageAndMailRailroadCar baggageAndMailRailroadCar = new BaggageAndMailRailroadCar(netWeight, grossWeight, maxBaggageItems, baggageHandlingMechanism);
        railroadCars.put(railroadCarId, baggageAndMailRailroadCar);

        if (isLightEnough(trainset, grossWeight, baggageAndMailRailroadCar)) {
            railroadCars.put(railroadCarId, baggageAndMailRailroadCar);
        }
    }

    private void createAndAttachRestaurantCar(List<Trainset> trainsets, Trainset trainset) {
        System.out.println("Enter the net weight of the car: ");
        int netWeight = readIntInput(0, Integer.MAX_VALUE);

        System.out.println("Enter tne gross weight of the car: ");
        int grossWeight = readIntInput(0, Integer.MAX_VALUE);

        System.out.println("Enter tne number of tables: ");
        int numberOfTables = readIntInput(0, Integer.MAX_VALUE);

        System.out.println("Enter tne seating capacity: ");
        int seatingCapacity = readIntInput(0, Integer.MAX_VALUE);

        System.out.println("Does the railroad car have a bar? (1 - Yes, 2 - No)");
        int bar = readIntInput(1,2);
        boolean hasBar = bar == 1;

        System.out.println("Enter the cuisine type");
        System.out.println("1 - Polish");
        System.out.println("2 - Japanese");
        System.out.println("3 - Thai");
        System.out.println("4 - Italian");
        System.out.println("5- French");
        System.out.println("6 - Mexican");
        System.out.println("7 - Other");
        int cuisineTypeChoice = readIntInput(1, 7);
        CuisineType cuisineType = null;
        switch (cuisineTypeChoice) {
            case 1:
                cuisineType = CuisineType.POLISH;
                break;
            case 2:
                cuisineType = CuisineType.JAPANESE;
                break;
            case 3:
                cuisineType = CuisineType.THAI;
                break;
            case 4:
                cuisineType = CuisineType.ITALIAN;
                break;
            case 5:
                cuisineType = CuisineType.FRENCH;
                break;
            case 6:
                cuisineType = CuisineType.MEXICAN;
                break;
            case 7:
                cuisineType = CuisineType.OTHER;
                break;
            default:
                System.out.println("ERROR: Invalid choice");
                return;
        }

        System.out.println("Is the railroad car connected to the electrical grid? (1 - Yes, 2 - No)");
        int connectedToGrid = readIntInput(1,2);
        boolean isConnectedToGrid = connectedToGrid == 1;

        scanner.nextLine();

        int railroadCarId = getNextRailroadCarId();
        RestaurantRailroadCar restaurantRailroadCar = new RestaurantRailroadCar(netWeight, grossWeight, numberOfTables, seatingCapacity, hasBar, cuisineType, isConnectedToGrid);
        railroadCars.put(railroadCarId, restaurantRailroadCar);

        if (isLightEnough(trainset, grossWeight, restaurantRailroadCar)) {
            railroadCars.put(railroadCarId, restaurantRailroadCar);
        }
    }

    private void createAndAttachBasicFreightCar(List<Trainset> trainsets, Trainset trainset) {
        System.out.println("Enter the net weight of the car: ");
        int netWeight = readIntInput(0, Integer.MAX_VALUE);

        System.out.println("Enter tne gross weight of the car: ");
        int grossWeight = readIntInput(0, Integer.MAX_VALUE);

        System.out.println("Enter the shipper");
        System.out.println("1 - PKP Cargo");
        System.out.println("2 - PKP LHS");
        System.out.println("3 - Kolej Mazowiecka");
        System.out.println("4 - Lotos Kolej");
        System.out.println("5- KOLPREM");
        System.out.println("6 - CTL Logistics");
        System.out.println("7 - Union Pacific");
        System.out.println("8 - BNSF");
        System.out.println("9 - AMTRAK");
        System.out.println("10 - OTHER");
        int shipperChoice = readIntInput(1, 10);
        Shipper shipper = null;
        switch (shipperChoice) {
            case 1:
                shipper = Shipper.PKP_CARGO;
                break;
            case 2:
                shipper = Shipper.PKP_LHS;
                break;
            case 3:
                shipper = Shipper.KOLEJ_MAZOWIECKA;
                break;
            case 4:
                shipper = Shipper.LOTOS_KOLEJ;
                break;
            case 5:
                shipper = Shipper.KOLPREM;
                break;
            case 6:
                shipper = Shipper.CTL_LOGISTICS;
                break;
            case 7:
                shipper = Shipper.UNION_PACIFIC;
                break;
            case 8:
                shipper = Shipper.BNSF;
                break;
            case 9:
                shipper = Shipper.AMTRAK;
                break;
            case 10:
                shipper = Shipper.OTHER;
                break;
            default:
                System.out.println("ERROR: Invalid choice");
                return;
        }

        System.out.println("Enter the security information");
        System.out.println("1 - Top secret");
        System.out.println("2 - Classified");
        System.out.println("3 - Confidential");
        System.out.println("4 - Restricted");
        System.out.println("5- Unclassified");
        int securityChoice = readIntInput(1, 5);
        SecurityInformation securityInformation = null;
        switch (securityChoice) {
            case 1:
                securityInformation = SecurityInformation.TOP_SECRET;
                break;
            case 2:
                securityInformation = SecurityInformation.CLASSIFIED;
                break;
            case 3:
                securityInformation = SecurityInformation.CONFIDENTIAL;
                break;
            case 4:
                securityInformation = SecurityInformation.RESTRICTED;
                break;
            case 5:
                securityInformation = SecurityInformation.UNCLASSIFIED;
                break;
            default:
                System.out.println("ERROR: Invalid choice");
                return;
        }

        System.out.println("Enter cargo capacity in m^3");
        int cargoCapacity = readIntInput(1, Integer.MAX_VALUE);

        System.out.println("Does the reailroad car have ventilation system? (1 - Yes, 2 - No)");
        int ventilation = readIntInput(1,2);
        boolean hasVentilationSystem = ventilation == 1;

        scanner.nextLine();

        int railroadCarId = getNextRailroadCarId();
        BasicFreightRailroadCar basicFreightRailroadCar = new BasicFreightRailroadCar(netWeight, grossWeight, shipper, securityInformation, cargoCapacity, hasVentilationSystem);
        railroadCars.put(railroadCarId, basicFreightRailroadCar);

        if (isLightEnough(trainset, grossWeight, basicFreightRailroadCar)) {
            railroadCars.put(railroadCarId, basicFreightRailroadCar);
        }

    }

    private void createAndAttachHeavyFreightCar(List<Trainset> trainsets, Trainset trainset) {
        System.out.println("Enter the net weight of the car: ");
        int netWeight = readIntInput(0, Integer.MAX_VALUE);

        System.out.println("Enter tne gross weight of the car: ");
        int grossWeight = readIntInput(0, Integer.MAX_VALUE);

        System.out.println("Enter the shipper");
        System.out.println("1 - PKP Cargo");
        System.out.println("2 - PKP LHS");
        System.out.println("3 - Kolej Mazowiecka");
        System.out.println("4 - Lotos Kolej");
        System.out.println("5- KOLPREM");
        System.out.println("6 - CTL Logistics");
        System.out.println("7 - Union Pacific");
        System.out.println("8 - BNSF");
        System.out.println("9 - AMTRAK");
        System.out.println("10 - OTHER");
        int shipperChoice = readIntInput(1, 10);
        Shipper shipper = null;
        switch (shipperChoice) {
            case 1:
                shipper = Shipper.PKP_CARGO;
                break;
            case 2:
                shipper = Shipper.PKP_LHS;
                break;
            case 3:
                shipper = Shipper.KOLEJ_MAZOWIECKA;
                break;
            case 4:
                shipper = Shipper.LOTOS_KOLEJ;
                break;
            case 5:
                shipper = Shipper.KOLPREM;
                break;
            case 6:
                shipper = Shipper.CTL_LOGISTICS;
                break;
            case 7:
                shipper = Shipper.UNION_PACIFIC;
                break;
            case 8:
                shipper = Shipper.BNSF;
                break;
            case 9:
                shipper = Shipper.AMTRAK;
                break;
            case 10:
                shipper = Shipper.OTHER;
                break;
            default:
                System.out.println("ERROR: Invalid choice");
                return;
        }

        System.out.println("Enter the security information");
        System.out.println("1 - Top secret");
        System.out.println("2 - Classified");
        System.out.println("3 - Confidential");
        System.out.println("4 - Restricted");
        System.out.println("5- Unclassified");
        int securityChoice = readIntInput(1, 5);
        SecurityInformation securityInformation = null;
        switch (securityChoice) {
            case 1:
                securityInformation = SecurityInformation.TOP_SECRET;
                break;
            case 2:
                securityInformation = SecurityInformation.CLASSIFIED;
                break;
            case 3:
                securityInformation = SecurityInformation.CONFIDENTIAL;
                break;
            case 4:
                securityInformation = SecurityInformation.RESTRICTED;
                break;
            case 5:
                securityInformation = SecurityInformation.UNCLASSIFIED;
                break;
            default:
                System.out.println("ERROR: Invalid choice");
                return;
        }

        System.out.println("Does the railroad car have side doors? (1 - Yes, 2 - No)");
        int sideDoors = readIntInput(1,2);
        boolean hasSideDoors = sideDoors == 1;

        System.out.println("Enter the brake system type");
        System.out.println("1 - Air");
        System.out.println("2 - Hydraulic");
        System.out.println("3 - Mechanical");
        System.out.println("4 - Electronic");
        System.out.println("5- Other");
        int brakeSystemChoice = readIntInput(1, 5);
        BrakeSystem brakeSystem = null;
        switch (brakeSystemChoice) {
            case 1:
                brakeSystem = BrakeSystem.AIR;
                break;
            case 2:
                brakeSystem = BrakeSystem.HYDRAULIC;
                break;
            case 3:
                brakeSystem = BrakeSystem.MECHANICAL;
                break;
            case 4:
                brakeSystem = BrakeSystem.ELECTRONIC;
                break;
            case 5:
                brakeSystem = BrakeSystem.OTHER;
                break;
            default:
                System.out.println("ERROR: Invalid choice");
                return;
        }

        scanner.nextLine();

        int railroadCarId = getNextRailroadCarId();
        HeavyFreightRailroadCar heavyFreightRailroadCar = new HeavyFreightRailroadCar(netWeight, grossWeight, shipper, securityInformation, hasSideDoors, brakeSystem);
        railroadCars.put(railroadCarId, heavyFreightRailroadCar);

        if (isLightEnough(trainset, grossWeight, heavyFreightRailroadCar)) {
            railroadCars.put(railroadCarId, heavyFreightRailroadCar);
        }

    }

    private void createAndAttachRefrigeratedCar(List<Trainset> trainsets, Trainset trainset) {
        System.out.println("Enter the net weight of the car: ");
        int netWeight = readIntInput(0, Integer.MAX_VALUE);

        System.out.println("Enter tne gross weight of the car: ");
        int grossWeight = readIntInput(0, Integer.MAX_VALUE);

        System.out.println("Enter the shipper");
        System.out.println("1 - PKP Cargo");
        System.out.println("2 - PKP LHS");
        System.out.println("3 - Kolej Mazowiecka");
        System.out.println("4 - Lotos Kolej");
        System.out.println("5- KOLPREM");
        System.out.println("6 - CTL Logistics");
        System.out.println("7 - Union Pacific");
        System.out.println("8 - BNSF");
        System.out.println("9 - AMTRAK");
        System.out.println("10 - OTHER");
        int shipperChoice = readIntInput(1, 10);
        Shipper shipper = null;
        switch (shipperChoice) {
            case 1:
                shipper = Shipper.PKP_CARGO;
                break;
            case 2:
                shipper = Shipper.PKP_LHS;
                break;
            case 3:
                shipper = Shipper.KOLEJ_MAZOWIECKA;
                break;
            case 4:
                shipper = Shipper.LOTOS_KOLEJ;
                break;
            case 5:
                shipper = Shipper.KOLPREM;
                break;
            case 6:
                shipper = Shipper.CTL_LOGISTICS;
                break;
            case 7:
                shipper = Shipper.UNION_PACIFIC;
                break;
            case 8:
                shipper = Shipper.BNSF;
                break;
            case 9:
                shipper = Shipper.AMTRAK;
                break;
            case 10:
                shipper = Shipper.OTHER;
                break;
            default:
                System.out.println("ERROR: Invalid choice");
                return;
        }

        System.out.println("Enter the security information");
        System.out.println("1 - Top secret");
        System.out.println("2 - Classified");
        System.out.println("3 - Confidential");
        System.out.println("4 - Restricted");
        System.out.println("5- Unclassified");
        int securityChoice = readIntInput(1, 5);
        SecurityInformation securityInformation = null;
        switch (securityChoice) {
            case 1:
                securityInformation = SecurityInformation.TOP_SECRET;
                break;
            case 2:
                securityInformation = SecurityInformation.CLASSIFIED;
                break;
            case 3:
                securityInformation = SecurityInformation.CONFIDENTIAL;
                break;
            case 4:
                securityInformation = SecurityInformation.RESTRICTED;
                break;
            case 5:
                securityInformation = SecurityInformation.UNCLASSIFIED;
                break;
            default:
                System.out.println("ERROR: Invalid choice");
                return;
        }

        System.out.println("Enter cargo capacity in m^3");
        int cargoCapacity = readIntInput(1, Integer.MAX_VALUE);

        System.out.println("Does the reailroad car have ventilation system? (1 - Yes, 2 - No)");
        int ventilation = readIntInput(1,2);
        boolean hasVentilationSystem = ventilation == 1;

        System.out.println("Enter min temperature in Celcius degrees ");
        int temperatureMinRange = readIntInput(1, Integer.MAX_VALUE);

        System.out.println("Enter max temperature in Celcius degrees");
        int temperatureMaxRange = readIntInput(1, Integer.MAX_VALUE);

        System.out.println("Does the railroad car have humidity control? (1 - Yes, 2 - No)");
        int control = readIntInput(1,2);
        boolean hasHumidityControl = control == 1;

        System.out.println("Is the railroad car connected to the electrical grid? (1 - Yes, 2 - No)");
        int connectedToGrid = readIntInput(1,2);
        boolean isConnectedToGrid = connectedToGrid == 1;

        scanner.nextLine();

        int railroadCarId = getNextRailroadCarId();
        RefrigeratedRailroadCar refrigeratedRailroadCar = new RefrigeratedRailroadCar(netWeight, grossWeight, shipper, securityInformation, cargoCapacity, hasVentilationSystem, temperatureMinRange, temperatureMaxRange, hasHumidityControl, isConnectedToGrid);
        railroadCars.put(railroadCarId, refrigeratedRailroadCar);

        if (isLightEnough(trainset, grossWeight, refrigeratedRailroadCar)) {
            railroadCars.put(railroadCarId, refrigeratedRailroadCar);
        }

    }

    private void createAndAttachLiquidMaterialsCar(List<Trainset> trainsets, Trainset trainset) {
        System.out.println("Enter the net weight of the car: ");
        int netWeight = readIntInput(0, Integer.MAX_VALUE);

        System.out.println("Enter tne gross weight of the car: ");
        int grossWeight = readIntInput(0, Integer.MAX_VALUE);

        System.out.println("Enter the shipper");
        System.out.println("1 - PKP Cargo");
        System.out.println("2 - PKP LHS");
        System.out.println("3 - Kolej Mazowiecka");
        System.out.println("4 - Lotos Kolej");
        System.out.println("5- KOLPREM");
        System.out.println("6 - CTL Logistics");
        System.out.println("7 - Union Pacific");
        System.out.println("8 - BNSF");
        System.out.println("9 - AMTRAK");
        System.out.println("10 - OTHER");
        int shipperChoice = readIntInput(1, 10);
        Shipper shipper = null;
        switch (shipperChoice) {
            case 1:
                shipper = Shipper.PKP_CARGO;
                break;
            case 2:
                shipper = Shipper.PKP_LHS;
                break;
            case 3:
                shipper = Shipper.KOLEJ_MAZOWIECKA;
                break;
            case 4:
                shipper = Shipper.LOTOS_KOLEJ;
                break;
            case 5:
                shipper = Shipper.KOLPREM;
                break;
            case 6:
                shipper = Shipper.CTL_LOGISTICS;
                break;
            case 7:
                shipper = Shipper.UNION_PACIFIC;
                break;
            case 8:
                shipper = Shipper.BNSF;
                break;
            case 9:
                shipper = Shipper.AMTRAK;
                break;
            case 10:
                shipper = Shipper.OTHER;
                break;
            default:
                System.out.println("ERROR: Invalid choice");
                return;
        }

        System.out.println("Enter the security information");
        System.out.println("1 - Top secret");
        System.out.println("2 - Classified");
        System.out.println("3 - Confidential");
        System.out.println("4 - Restricted");
        System.out.println("5- Unclassified");
        int securityChoice = readIntInput(1, 5);
        SecurityInformation securityInformation = null;
        switch (securityChoice) {
            case 1:
                securityInformation = SecurityInformation.TOP_SECRET;
                break;
            case 2:
                securityInformation = SecurityInformation.CLASSIFIED;
                break;
            case 3:
                securityInformation = SecurityInformation.CONFIDENTIAL;
                break;
            case 4:
                securityInformation = SecurityInformation.RESTRICTED;
                break;
            case 5:
                securityInformation = SecurityInformation.UNCLASSIFIED;
                break;
            default:
                System.out.println("ERROR: Invalid choice");
                return;
        }

        System.out.println("Enter cargo capacity in m^3");
        int cargoCapacity = readIntInput(1, Integer.MAX_VALUE);

        System.out.println("Does the reailroad car have ventilation system? (1 - Yes, 2 - No)");
        int ventilation = readIntInput(1,2);
        boolean hasVentilationSystem = ventilation == 1;

        System.out.println("Enter the pump type");
        System.out.println("1 - Piston");
        System.out.println("2 - Propeller");
        System.out.println("3 - Impeller");
        System.out.println("4 - Submersible");
        System.out.println("5- Lobe");
        System.out.println("6 - Other");
        int pumpTypeChoice = readIntInput(1, 6);
        PumpType pumpType = null;
        switch (pumpTypeChoice) {
            case 1:
                pumpType= PumpType.PISTON;
                break;
            case 2:
                pumpType = PumpType.PROPELLER;
                break;
            case 3:
                pumpType = PumpType.IMPELLER;
                break;
            case 4:
                pumpType = PumpType.SUBMERSIBLE;
                break;
            case 5:
                pumpType = PumpType.LOBE;
                break;
            case 6:
                pumpType = PumpType.OTHER;
                break;
            default:
                System.out.println("ERROR: Invalid choice");
                return;
        }

        System.out.println("Enter the tank material");
        System.out.println("1 - Stainless steel");
        System.out.println("2 - Aluminium");
        System.out.println("3 - Titanium");
        System.out.println("4 - Copper");
        System.out.println("5- Plastic");
        System.out.println("6 - Rubber");
        System.out.println("7 - Other");
        int tankMaterialChoice = readIntInput(1, 7);
        TankMaterial tankMaterial = null;
        switch (tankMaterialChoice) {
            case 1:
                tankMaterial= TankMaterial.STAINLESS_STEEL;
                break;
            case 2:
                tankMaterial = TankMaterial.ALUMINIUM;
                break;
            case 3:
                tankMaterial = TankMaterial.TITANIUM;
                break;
            case 4:
                tankMaterial = TankMaterial.COPPER;
                break;
            case 5:
                tankMaterial = TankMaterial.PLASTIC;
                break;
            case 6:
                tankMaterial = TankMaterial.RUBBER;
                break;
            case 7:
                tankMaterial = TankMaterial.OTHER;
                break;
            default:
                System.out.println("ERROR: Invalid choice");
                return;
        }

        scanner.nextLine();

        int railroadCarId = getNextRailroadCarId();
        LiquidMaterialsRailroadCar liquidMaterialsRailroadCar = new LiquidMaterialsRailroadCar(netWeight, grossWeight, shipper, securityInformation, cargoCapacity, hasVentilationSystem, pumpType, tankMaterial);
        railroadCars.put(railroadCarId, liquidMaterialsRailroadCar);

        if (isLightEnough(trainset, grossWeight, liquidMaterialsRailroadCar)) {
            railroadCars.put(railroadCarId, liquidMaterialsRailroadCar);
        }
    }

    private void createAndAttachGaseousMaterialsCar(List<Trainset> trainsets, Trainset trainset) {
        System.out.println("Enter the net weight of the car: ");
        int netWeight = readIntInput(0, Integer.MAX_VALUE);
        System.out.println("Enter tne gross weight of the car: ");
        int grossWeight = readIntInput(0, Integer.MAX_VALUE);

        System.out.println("Enter the shipper");
        System.out.println("1 - PKP Cargo");
        System.out.println("2 - PKP LHS");
        System.out.println("3 - Kolej Mazowiecka");
        System.out.println("4 - Lotos Kolej");
        System.out.println("5- KOLPREM");
        System.out.println("6 - CTL Logistics");
        System.out.println("7 - Union Pacific");
        System.out.println("8 - BNSF");
        System.out.println("9 - AMTRAK");
        System.out.println("10 - OTHER");
        int shipperChoice = readIntInput(1, 10);
        Shipper shipper = null;
        switch (shipperChoice) {
            case 1:
                shipper = Shipper.PKP_CARGO;
                break;
            case 2:
                shipper = Shipper.PKP_LHS;
                break;
            case 3:
                shipper = Shipper.KOLEJ_MAZOWIECKA;
                break;
            case 4:
                shipper = Shipper.LOTOS_KOLEJ;
                break;
            case 5:
                shipper = Shipper.KOLPREM;
                break;
            case 6:
                shipper = Shipper.CTL_LOGISTICS;
                break;
            case 7:
                shipper = Shipper.UNION_PACIFIC;
                break;
            case 8:
                shipper = Shipper.BNSF;
                break;
            case 9:
                shipper = Shipper.AMTRAK;
                break;
            case 10:
                shipper = Shipper.OTHER;
                break;
            default:
                System.out.println("ERROR: Invalid choice");
                return;
        }

        System.out.println("Enter the security information");
        System.out.println("1 - Top secret");
        System.out.println("2 - Classified");
        System.out.println("3 - Confidential");
        System.out.println("4 - Restricted");
        System.out.println("5- Unclassified");
        int securityChoice = readIntInput(1, 5);
        SecurityInformation securityInformation = null;
        switch (securityChoice) {
            case 1:
                securityInformation = SecurityInformation.TOP_SECRET;
                break;
            case 2:
                securityInformation = SecurityInformation.CLASSIFIED;
                break;
            case 3:
                securityInformation = SecurityInformation.CONFIDENTIAL;
                break;
            case 4:
                securityInformation = SecurityInformation.RESTRICTED;
                break;
            case 5:
                securityInformation = SecurityInformation.UNCLASSIFIED;
                break;
            default:
                System.out.println("ERROR: Invalid choice");
                return;
        }

        System.out.println("Enter cargo capacity in m^3");
        int cargoCapacity = readIntInput(1, Integer.MAX_VALUE);

        System.out.println("Does the reailroad car have ventilation system? (1 - Yes, 2 - No)");
        int ventilation = readIntInput(1,2);
        boolean hasVentilationSystem = ventilation == 1;

        System.out.println("Does the reailroad car have pressure vessel? (1 - Yes, 2 - No)");
        int vessel = readIntInput(1,2);
        boolean hasPressureVessel = vessel == 1;

        System.out.println("Enter the gas type");
        System.out.println("1 - Methane");
        System.out.println("2 - Ethane");
        System.out.println("3 - Propane");
        System.out.println("4 - Butane");
        System.out.println("5- Oxygen");
        System.out.println("6 - Hydrogen");
        System.out.println("7 - Helium");
        System.out.println("8 - Chlorine");
        System.out.println("9 - Other");
        int gasTypeChoice = readIntInput(1, 10);
        GasType gasType = null;
        switch (gasTypeChoice) {
            case 1:
                gasType = GasType.METHANE;
                break;
            case 2:
                gasType = GasType.ETHANE;
                break;
            case 3:
                gasType = GasType.PROPANE;
                break;
            case 4:
                gasType = GasType.BUTANE;
                break;
            case 5:
                gasType = GasType.OXYGEN;
                break;
            case 6:
                gasType = GasType.HYDROGEN;
                break;
            case 7:
                gasType = GasType.HELIUM;
                break;
            case 8:
                gasType = GasType.CHLORINE;
                break;
            case 9:
                gasType = GasType.OTHER;
                break;
            default:
                System.out.println("ERROR: Invalid choice");
                return;
        }

        scanner.nextLine();

        int railroadCarId = getNextRailroadCarId();
        GaseousMaterialsRailroadCar gaseousMaterialsRailroadCar = new GaseousMaterialsRailroadCar(netWeight, grossWeight, shipper, securityInformation, cargoCapacity, hasVentilationSystem, hasPressureVessel, gasType);
        railroadCars.put(railroadCarId, gaseousMaterialsRailroadCar);

        if (isLightEnough(trainset, grossWeight, gaseousMaterialsRailroadCar)) {
            railroadCars.put(railroadCarId, gaseousMaterialsRailroadCar);
        }
    }

    private void createAndAttachExplosivesCar(List<Trainset> trainsets, Trainset trainset) {
        System.out.println("Enter the net weight of the car: ");
        int netWeight = readIntInput(0, Integer.MAX_VALUE);

        System.out.println("Enter tne gross weight of the car: ");
        int grossWeight = readIntInput(0, Integer.MAX_VALUE);

        System.out.println("Enter the shipper");
        System.out.println("1 - PKP Cargo");
        System.out.println("2 - PKP LHS");
        System.out.println("3 - Kolej Mazowiecka");
        System.out.println("4 - Lotos Kolej");
        System.out.println("5- KOLPREM");
        System.out.println("6 - CTL Logistics");
        System.out.println("7 - Union Pacific");
        System.out.println("8 - BNSF");
        System.out.println("9 - AMTRAK");
        System.out.println("10 - OTHER");
        int shipperChoice = readIntInput(1, 10);
        Shipper shipper = null;
        switch (shipperChoice) {
            case 1:
                shipper = Shipper.PKP_CARGO;
                break;
            case 2:
                shipper = Shipper.PKP_LHS;
                break;
            case 3:
                shipper = Shipper.KOLEJ_MAZOWIECKA;
                break;
            case 4:
                shipper = Shipper.LOTOS_KOLEJ;
                break;
            case 5:
                shipper = Shipper.KOLPREM;
                break;
            case 6:
                shipper = Shipper.CTL_LOGISTICS;
                break;
            case 7:
                shipper = Shipper.UNION_PACIFIC;
                break;
            case 8:
                shipper = Shipper.BNSF;
                break;
            case 9:
                shipper = Shipper.AMTRAK;
                break;
            case 10:
                shipper = Shipper.OTHER;
                break;
            default:
                System.out.println("ERROR: Invalid choice");
                return;
        }

        System.out.println("Enter the security information");
        System.out.println("1 - Top secret");
        System.out.println("2 - Classified");
        System.out.println("3 - Confidential");
        System.out.println("4 - Restricted");
        System.out.println("5- Unclassified");
        int securityChoice = readIntInput(1, 5);
        SecurityInformation securityInformation = null;
        switch (securityChoice) {
            case 1:
                securityInformation = SecurityInformation.TOP_SECRET;
                break;
            case 2:
                securityInformation = SecurityInformation.CLASSIFIED;
                break;
            case 3:
                securityInformation = SecurityInformation.CONFIDENTIAL;
                break;
            case 4:
                securityInformation = SecurityInformation.RESTRICTED;
                break;
            case 5:
                securityInformation = SecurityInformation.UNCLASSIFIED;
                break;
            default:
                System.out.println("ERROR: Invalid choice");
                return;
        }

        System.out.println("Does the railroad car have side doors? (1 - Yes, 2 - No)");
        int sideDoors = readIntInput(1,2);
        boolean hasSideDoors = sideDoors == 1;

        System.out.println("Enter the brake system type");
        System.out.println("1 - Air");
        System.out.println("2 - Hydraulic");
        System.out.println("3 - Mechanical");
        System.out.println("4 - Electronic");
        System.out.println("5- Other");
        int brakeSystemChoice = readIntInput(1, 5);
        BrakeSystem brakeSystem = null;
        switch (brakeSystemChoice) {
            case 1:
                brakeSystem = BrakeSystem.AIR;
                break;
            case 2:
                brakeSystem = BrakeSystem.HYDRAULIC;
                break;
            case 3:
                brakeSystem = BrakeSystem.MECHANICAL;
                break;
            case 4:
                brakeSystem = BrakeSystem.ELECTRONIC;
                break;
            case 5:
                brakeSystem = BrakeSystem.OTHER;
                break;
            default:
                System.out.println("ERROR: Invalid choice");
                return;
        }

        System.out.println("Enter the explosive type");
        System.out.println("1 - TNT");
        System.out.println("2 - Dynamite");
        System.out.println("3 - C4");
        System.out.println("4 - Nitroglycerin");
        System.out.println("5 - Flares");
        System.out.println("6 - Fireworks");
        System.out.println("7 - Other");
        int explosiveTypeChoice = readIntInput(1, 7);
        ExplosiveType explosiveType = null;
        switch (explosiveTypeChoice) {
            case 1:
                explosiveType = ExplosiveType.TNT;
                break;
            case 2:
                explosiveType = ExplosiveType.DYNAMITE;
                break;
            case 3:
                explosiveType = ExplosiveType.C4;
                break;
            case 4:
                explosiveType = ExplosiveType.NITROGLYCERIN;
                break;
            case 5:
                explosiveType = ExplosiveType.FLARES;
                break;
            case 6:
                explosiveType = ExplosiveType.FIREWORKS;
                break;
            case 7:
                explosiveType = ExplosiveType.OTHER;
                break;
            default:
                System.out.println("ERROR: Invalid choice");
                return;
        }

        System.out.println("Enter the locking mechanism type");
        System.out.println("1 - Key lock");
        System.out.println("2 - Padlock");
        System.out.println("3 - Electronic lock");
        System.out.println("4 - Chain lock");
        System.out.println("5- Other");
        int lockingMechanismChoice = readIntInput(1, 5);
        LockingMechanism lockingMechanism = null;
        switch (lockingMechanismChoice) {
            case 1:
                lockingMechanism = LockingMechanism.KEY_LOCK;
                break;
            case 2:
                lockingMechanism = LockingMechanism.PADLOCK;
                break;
            case 3:
                lockingMechanism = LockingMechanism.ELECTRONIC_LOCK;
                break;
            case 4:
                lockingMechanism = LockingMechanism.CHAIN_LOCK;
                break;
            case 5:
                lockingMechanism = LockingMechanism.OTHER;
                break;
            default:
                System.out.println("ERROR: Invalid choice");
                return;
        }

        scanner.nextLine();

        int railroadCarId = getNextRailroadCarId();
        ExplosivesRailroadCar explosivesRailroadCar = new ExplosivesRailroadCar(netWeight, grossWeight, shipper, securityInformation, hasSideDoors, brakeSystem, explosiveType, lockingMechanism);
        railroadCars.put(railroadCarId, explosivesRailroadCar);

        if (isLightEnough(trainset, grossWeight, explosivesRailroadCar)) {
            railroadCars.put(railroadCarId, explosivesRailroadCar);
        }
    }

    private void createAndAttachToxicMaterialCar(List<Trainset> trainsets, Trainset trainset) {
        System.out.println("Enter the net weight of the car: ");
        int netWeight = readIntInput(0, Integer.MAX_VALUE);

        System.out.println("Enter tne gross weight of the car: ");
        int grossWeight = readIntInput(0, Integer.MAX_VALUE);

        System.out.println("Enter the shipper");
        System.out.println("1 - PKP Cargo");
        System.out.println("2 - PKP LHS");
        System.out.println("3 - Kolej Mazowiecka");
        System.out.println("4 - Lotos Kolej");
        System.out.println("5- KOLPREM");
        System.out.println("6 - CTL Logistics");
        System.out.println("7 - Union Pacific");
        System.out.println("8 - BNSF");
        System.out.println("9 - AMTRAK");
        System.out.println("10 - OTHER");
        int shipperChoice = readIntInput(1, 10);
        Shipper shipper = null;
        switch (shipperChoice) {
            case 1:
                shipper = Shipper.PKP_CARGO;
                break;
            case 2:
                shipper = Shipper.PKP_LHS;
                break;
            case 3:
                shipper = Shipper.KOLEJ_MAZOWIECKA;
                break;
            case 4:
                shipper = Shipper.LOTOS_KOLEJ;
                break;
            case 5:
                shipper = Shipper.KOLPREM;
                break;
            case 6:
                shipper = Shipper.CTL_LOGISTICS;
                break;
            case 7:
                shipper = Shipper.UNION_PACIFIC;
                break;
            case 8:
                shipper = Shipper.BNSF;
                break;
            case 9:
                shipper = Shipper.AMTRAK;
                break;
            case 10:
                shipper = Shipper.OTHER;
                break;
            default:
                System.out.println("ERROR: Invalid choice");
                return;
        }

        System.out.println("Enter the security information");
        System.out.println("1 - Top secret");
        System.out.println("2 - Classified");
        System.out.println("3 - Confidential");
        System.out.println("4 - Restricted");
        System.out.println("5- Unclassified");
        int securityChoice = readIntInput(1, 5);
        SecurityInformation securityInformation = null;
        switch (securityChoice) {
            case 1:
                securityInformation = SecurityInformation.TOP_SECRET;
                break;
            case 2:
                securityInformation = SecurityInformation.CLASSIFIED;
                break;
            case 3:
                securityInformation = SecurityInformation.CONFIDENTIAL;
                break;
            case 4:
                securityInformation = SecurityInformation.RESTRICTED;
                break;
            case 5:
                securityInformation = SecurityInformation.UNCLASSIFIED;
                break;
            default:
                System.out.println("ERROR: Invalid choice");
                return;
        }

        System.out.println("Does the railroad car have side doors? (1 - Yes, 2 - No)");
        int sideDoors = readIntInput(1,2);
        boolean hasSideDoors = sideDoors == 1;

        System.out.println("Enter the brake system type");
        System.out.println("1 - Air");
        System.out.println("2 - Hydraulic");
        System.out.println("3 - Mechanical");
        System.out.println("4 - Electronic");
        System.out.println("5- Other");
        int brakeSystemChoice = readIntInput(1, 5);
        BrakeSystem brakeSystem = null;
        switch (brakeSystemChoice) {
            case 1:
                brakeSystem = BrakeSystem.AIR;
                break;
            case 2:
                brakeSystem = BrakeSystem.HYDRAULIC;
                break;
            case 3:
                brakeSystem = BrakeSystem.MECHANICAL;
                break;
            case 4:
                brakeSystem = BrakeSystem.ELECTRONIC;
                break;
            case 5:
                brakeSystem = BrakeSystem.OTHER;
                break;
            default:
                System.out.println("ERROR: Invalid choice");
                return;
        }

        System.out.println("Does the railroad car have warning labels? (1 - Yes, 2 - No)");
        int warningLabels = readIntInput(1,2);
        boolean hasWarningLabels = sideDoors == 1;

        System.out.println("Enter the type of hazmat suit required");
        System.out.println("1 - Full body suit");
        System.out.println("2 - Respirator");
        System.out.println("3 - Gloves");
        System.out.println("4 - Boots");
        System.out.println("5- Face shield");
        System.out.println("6 - None");
        int hazmatSuitChoice = readIntInput(1, 6);
        HazmatSuit hazmatSuit = null;
        switch (hazmatSuitChoice) {
            case 1:
                hazmatSuit= HazmatSuit.FULL_BODY_SUIT;
                break;
            case 2:
                hazmatSuit = HazmatSuit.RESPIRATOR;
                break;
            case 3:
                hazmatSuit = HazmatSuit.GLOVES;
                break;
            case 4:
                hazmatSuit = HazmatSuit.BOOTS;
                break;
            case 5:
                hazmatSuit = HazmatSuit.FACE_SHIELD;
                break;
            case 6:
                hazmatSuit = HazmatSuit.NONE;
                break;
            default:
                System.out.println("ERROR: Invalid choice");
                return;
        }

        scanner.nextLine();

        int railroadCarId = getNextRailroadCarId();
        ToxicMaterialsRailroadCar toxicMaterialsRailroadCar = new ToxicMaterialsRailroadCar(netWeight, grossWeight, shipper, securityInformation, hasSideDoors, brakeSystem, hasWarningLabels, hazmatSuit);
        railroadCars.put(railroadCarId, toxicMaterialsRailroadCar);

        if (isLightEnough(trainset, grossWeight, toxicMaterialsRailroadCar)) {
            railroadCars.put(railroadCarId, toxicMaterialsRailroadCar);
        }
    }

    private void createAndAttachLiquidToxicMaterialCar(List<Trainset> trainsets, Trainset trainset) {
        System.out.println("Enter the net weight of the car: ");
        int netWeight = readIntInput(0, Integer.MAX_VALUE);

        System.out.println("Enter tne gross weight of the car: ");
        int grossWeight = readIntInput(0, Integer.MAX_VALUE);

        System.out.println("Enter the shipper");
        System.out.println("1 - PKP Cargo");
        System.out.println("2 - PKP LHS");
        System.out.println("3 - Kolej Mazowiecka");
        System.out.println("4 - Lotos Kolej");
        System.out.println("5- KOLPREM");
        System.out.println("6 - CTL Logistics");
        System.out.println("7 - Union Pacific");
        System.out.println("8 - BNSF");
        System.out.println("9 - AMTRAK");
        System.out.println("10 - OTHER");
        int shipperChoice = readIntInput(1, 10);
        Shipper shipper = null;
        switch (shipperChoice) {
            case 1:
                shipper = Shipper.PKP_CARGO;
                break;
            case 2:
                shipper = Shipper.PKP_LHS;
                break;
            case 3:
                shipper = Shipper.KOLEJ_MAZOWIECKA;
                break;
            case 4:
                shipper = Shipper.LOTOS_KOLEJ;
                break;
            case 5:
                shipper = Shipper.KOLPREM;
                break;
            case 6:
                shipper = Shipper.CTL_LOGISTICS;
                break;
            case 7:
                shipper = Shipper.UNION_PACIFIC;
                break;
            case 8:
                shipper = Shipper.BNSF;
                break;
            case 9:
                shipper = Shipper.AMTRAK;
                break;
            case 10:
                shipper = Shipper.OTHER;
                break;
            default:
                System.out.println("ERROR: Invalid choice");
                return;
        }

        System.out.println("Enter the security information");
        System.out.println("1 - Top secret");
        System.out.println("2 - Classified");
        System.out.println("3 - Confidential");
        System.out.println("4 - Restricted");
        System.out.println("5- Unclassified");
        int securityChoice = readIntInput(1, 5);
        SecurityInformation securityInformation = null;
        switch (securityChoice) {
            case 1:
                securityInformation = SecurityInformation.TOP_SECRET;
                break;
            case 2:
                securityInformation = SecurityInformation.CLASSIFIED;
                break;
            case 3:
                securityInformation = SecurityInformation.CONFIDENTIAL;
                break;
            case 4:
                securityInformation = SecurityInformation.RESTRICTED;
                break;
            case 5:
                securityInformation = SecurityInformation.UNCLASSIFIED;
                break;
            default:
                System.out.println("ERROR: Invalid choice");
                return;
        }

        System.out.println("Does the railroad car have side doors? (1 - Yes, 2 - No)");
        int sideDoors = readIntInput(1,2);
        boolean hasSideDoors = sideDoors == 1;

        System.out.println("Enter the brake system type");
        System.out.println("1 - Air");
        System.out.println("2 - Hydraulic");
        System.out.println("3 - Mechanical");
        System.out.println("4 - Electronic");
        System.out.println("5- Other");
        int brakeSystemChoice = readIntInput(1, 5);
        BrakeSystem brakeSystem = null;
        switch (brakeSystemChoice) {
            case 1:
                brakeSystem = BrakeSystem.AIR;
                break;
            case 2:
                brakeSystem = BrakeSystem.HYDRAULIC;
                break;
            case 3:
                brakeSystem = BrakeSystem.MECHANICAL;
                break;
            case 4:
                brakeSystem = BrakeSystem.ELECTRONIC;
                break;
            case 5:
                brakeSystem = BrakeSystem.OTHER;
                break;
            default:
                System.out.println("ERROR: Invalid choice");
                return;
        }

        System.out.println("Does the railroad car have warning labels? (1 - Yes, 2 - No)");
        int warningLabels = readIntInput(1,2);
        boolean hasWarningLabels = sideDoors == 1;

        System.out.println("Enter the type of hazmat suit required");
        System.out.println("1 - Full body suit");
        System.out.println("2 - Respirator");
        System.out.println("3 - Gloves");
        System.out.println("4 - Boots");
        System.out.println("5- Face shield");
        System.out.println("6 - None");
        int hazmatSuitChoice = readIntInput(1, 6);
        HazmatSuit hazmatSuit = null;
        switch (hazmatSuitChoice) {
            case 1:
                hazmatSuit= HazmatSuit.FULL_BODY_SUIT;
                break;
            case 2:
                hazmatSuit = HazmatSuit.RESPIRATOR;
                break;
            case 3:
                hazmatSuit = HazmatSuit.GLOVES;
                break;
            case 4:
                hazmatSuit = HazmatSuit.BOOTS;
                break;
            case 5:
                hazmatSuit = HazmatSuit.FACE_SHIELD;
                break;
            case 6:
                hazmatSuit = HazmatSuit.NONE;
                break;
            default:
                System.out.println("ERROR: Invalid choice");
                return;
        }

        System.out.println("Enter the pump type");
        System.out.println("1 - Piston");
        System.out.println("2 - Propeller");
        System.out.println("3 - Impeller");
        System.out.println("4 - Submersible");
        System.out.println("5- Lobe");
        System.out.println("6 - Other");
        int pumpTypeChoice = readIntInput(1, 6);
        PumpType pumpType = null;
        switch (pumpTypeChoice) {
            case 1:
                pumpType= PumpType.PISTON;
                break;
            case 2:
                pumpType = PumpType.PROPELLER;
                break;
            case 3:
                pumpType = PumpType.IMPELLER;
                break;
            case 4:
                pumpType = PumpType.SUBMERSIBLE;
                break;
            case 5:
                pumpType = PumpType.LOBE;
                break;
            case 6:
                pumpType = PumpType.OTHER;
                break;
            default:
                System.out.println("ERROR: Invalid choice");
                return;
        }

        System.out.println("Enter the tank material");
        System.out.println("1 - Stainless steel");
        System.out.println("2 - Aluminium");
        System.out.println("3 - Titanium");
        System.out.println("4 - Copper");
        System.out.println("5- Plastic");
        System.out.println("6 - Rubber");
        System.out.println("7 - Other");
        int tankMaterialChoice = readIntInput(1, 7);
        TankMaterial tankMaterial = null;
        switch (tankMaterialChoice) {
            case 1:
                tankMaterial= TankMaterial.STAINLESS_STEEL;
                break;
            case 2:
                tankMaterial = TankMaterial.ALUMINIUM;
                break;
            case 3:
                tankMaterial = TankMaterial.TITANIUM;
                break;
            case 4:
                tankMaterial = TankMaterial.COPPER;
                break;
            case 5:
                tankMaterial = TankMaterial.PLASTIC;
                break;
            case 6:
                tankMaterial = TankMaterial.RUBBER;
                break;
            case 7:
                tankMaterial = TankMaterial.OTHER;
                break;
            default:
                System.out.println("ERROR: Invalid choice");
                return;
        }

        System.out.println("Is the freight expensive? (1 - Yes, 2 - No)");
        int expenisve = readIntInput(1,2);
        boolean isExpenisve = expenisve == 1;

        System.out.println("Does the railroad car have cargo tracker? (1 - Yes, 2 - No)");
        int tracking = readIntInput(1,2);
        boolean hasCargoTracking = tracking == 1;

        scanner.nextLine();

        int railroadCarId = getNextRailroadCarId();
        LiquidToxicMaterialRailroadCar liquidToxicMaterialRailroadCar = new LiquidToxicMaterialRailroadCar(netWeight, grossWeight, shipper, securityInformation, hasSideDoors, brakeSystem, hasWarningLabels, hazmatSuit, pumpType, tankMaterial, isExpenisve, hasCargoTracking);
        railroadCars.put(railroadCarId, liquidToxicMaterialRailroadCar);

        if (isLightEnough(trainset, grossWeight, liquidToxicMaterialRailroadCar)) {
            railroadCars.put(railroadCarId, liquidToxicMaterialRailroadCar);
        }
    }

    boolean isLightEnough(Trainset trainset, double grossWeight, RailroadCar railroadCar) {
        double totalGrossWeight = 0.0;
        for (RailroadCar car : trainset.getRailroadCars()) {
            totalGrossWeight += car.getGrossWeight();
        }
        totalGrossWeight += grossWeight;

        if (totalGrossWeight > trainset.getLocomotive().getMaxWeightOfLoad()) {
            System.out.println("ERROR: The weight a locomotive car carry exceeded by " + (int) (totalGrossWeight - trainset.getLocomotive().getMaxWeightOfLoad()) + " kg");
            return false;
        } else {
            try {
                trainset.addRailroadCar(railroadCar);
                System.out.println("Railroad car created and added to trainset, ID: " + railroadCar.getId());
                return true;
            } catch (Exception e) {
                System.out.println(e.getMessage());
                return false;
            }
        }
    }

    private int readIntInput(int min, int max) {
        int choice = -1;
        while (choice < min || choice > max) {
            try {
                //System.out.println("Enter your choice: ");
                choice = scanner.nextInt();
                if (choice < min || choice > max) {
                    System.out.println("ERROR: Please enter a number between " + min + " and " + max + ".");
                }
            } catch (InputMismatchException e) {
                System.out.println("ERROR: Please enter a number.");
                scanner.next();
            }
        }
        return choice;
    }
}
