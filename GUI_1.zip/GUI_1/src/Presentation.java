public class Presentation {
    public static void main(String[] args) {
        RailwayApp railwayApp = new RailwayApp();
        railwayApp.runApp();
    }
}