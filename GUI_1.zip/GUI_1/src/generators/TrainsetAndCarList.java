package generators;

import trainset.Trainset;
import trainset.railroadcar.RailroadCar;

import java.util.List;

public class TrainsetAndCarList {
    private List<Trainset> trainsets;
    private List<RailroadCar> railroadCars;

    public TrainsetAndCarList(List<Trainset> trainsets, List<RailroadCar> railroadCars) {
        this.trainsets = trainsets;
        this.railroadCars = railroadCars;
    }

    public List<Trainset> getTrainsets() {
        return trainsets;
    }

    public List<RailroadCar> getRailroadCars() {
        return railroadCars;
    }
}
