package generators;

import railwaystation.RailwayStation;
import railwaystation.RailwayStationNetwork;
import trainset.Trainset;
import trainset.TrainsetMovement;
import trainset.locomotive.Locomotive;
import trainset.railroadcar.RailroadCar;
import trainset.railroadcar.baggageandmail.BaggageAndMailRailroadCar;
import trainset.railroadcar.baggageandmail.BaggageHandlingMechanism;
import trainset.railroadcar.freight.SecurityInformation;
import trainset.railroadcar.freight.Shipper;
import trainset.railroadcar.freight.basicfreight.BasicFreightRailroadCar;
import trainset.railroadcar.freight.basicfreight.gaseousmaterials.GasType;
import trainset.railroadcar.freight.basicfreight.gaseousmaterials.GaseousMaterialsRailroadCar;
import trainset.railroadcar.freight.basicfreight.liquidmaterials.LiquidMaterialsRailroadCar;
import trainset.railroadcar.freight.basicfreight.liquidmaterials.PumpType;
import trainset.railroadcar.freight.basicfreight.liquidmaterials.TankMaterial;
import trainset.railroadcar.freight.basicfreight.refrigerated.RefrigeratedRailroadCar;
import trainset.railroadcar.freight.heavyfreight.BrakeSystem;
import trainset.railroadcar.freight.heavyfreight.HeavyFreightRailroadCar;
import trainset.railroadcar.freight.heavyfreight.explosives.ExplosiveType;
import trainset.railroadcar.freight.heavyfreight.explosives.ExplosivesRailroadCar;
import trainset.railroadcar.freight.heavyfreight.explosives.LockingMechanism;
import trainset.railroadcar.freight.heavyfreight.toxicmaterials.HazmatSuit;
import trainset.railroadcar.freight.heavyfreight.toxicmaterials.ToxicMaterialsRailroadCar;
import trainset.railroadcar.freight.heavyfreight.toxicmaterials.liquidtoxicmaterial.LiquidToxicMaterialRailroadCar;
import trainset.railroadcar.passenger.PassengerRailroadCar;
import trainset.railroadcar.passenger.SeatType;
import trainset.railroadcar.postoffice.PostOfficeRailroad;
import trainset.railroadcar.restaurant.CuisineType;
import trainset.railroadcar.restaurant.RestaurantRailroadCar;

import java.util.ArrayList;
import java.util.List;

public class TrainsetGenerator {
    public static TrainsetAndCarList generateTrainsets(int numberOfTrainsets, RailwayStationNetwork railwayStationNetwork) {
        List<Trainset> trainsets = new ArrayList<>();
        List<RailwayStation> stations = railwayStationNetwork.getStations();
        List<RailroadCar> railroadCars = new ArrayList<>();

        for (int i = 0; i < numberOfTrainsets; i++) {
            int maxNumOfCars = (int) (Math.random() * 10) + 11;
            int maxWeightOfLoad = (int) (Math.random() * 10_000_000) + 9_000_000;
            int maxNumOfCarsConnected = (int) (Math.random() * 5) + 5;
            int randomStationId1 = (int) (Math.random() * stations.size());
            int randomStationId2 = (int) (Math.random() * stations.size());
            int randomStationId3 = (int) (Math.random() * stations.size());
            double speed = (Math.random() * 100) + 50;
            String name = "Locomotive " + (i + 1);
            Locomotive locomotive = new Locomotive(maxNumOfCars, maxWeightOfLoad, maxNumOfCarsConnected, name, stations.get(randomStationId1), stations.get(randomStationId2), stations.get(randomStationId3), speed);

            Trainset trainset = new Trainset(locomotive);

            int numberOfRailroadCars = (int) (Math.random() * 6) + 5;
            for (int j = 0; j < numberOfRailroadCars; j++) {
                RailroadCar car = generateRandomRailroadCar();
                try {
                    trainset.addRailroadCar(car);
                    railroadCars.add(car);
                } catch (Exception e) {
                    //System.out.println("Failed to add railroad car");
                }
            }
            trainsets.add(trainset);
        }
        return new TrainsetAndCarList(trainsets, railroadCars);
    }

    private static RailroadCar generateRandomRailroadCar() {
        int numberOfTypes = 12 + 1;
        int randomType = (int) (Math.random() * numberOfTypes);

        if (randomType == 1) {
            return createPassengerRailroadCar();
        } else if (randomType == 2) {
            return createPostOfficeRailroadCar();
        } else if (randomType == 3) {
            return createBaggageAndMailCar();
        } else if (randomType == 4) {
            return createRestaurantCar();
        } else if (randomType == 5) {
            return createBasicFreightCar();
        } else if (randomType == 6) {
            return createHeavyFreightCar();
        } else if (randomType == 7) {
            return createRefrigeratedCar();
        } else if (randomType == 8) {
            return createLiquidMaterialsCar();
        }else if (randomType == 9) {
            return createGaseousMaterialsCar();
        }else if (randomType == 10) {
            return createExplosivesCar();
        }else if (randomType == 11) {
            return createToxicMaterialCar();
        } else {
            return createLiquidToxicMaterialCar();
        }
    }

    private static RailroadCar createPassengerRailroadCar() {
        double netWeight = (Math.random() * 20000) + 30000;
        double grossWeight = (Math.random() * 20000) + 40000;
        int numberOfPassengers = (int) (Math.random() * 30) + 20;
        int numberOfSeats = (int) (Math.random() * 30) + 50;
        boolean isConnectedToGrid = Math.random() < 0.5;
        SeatType[] seatTypes = SeatType.values();
        SeatType seatType = seatTypes[(int) (Math.random() * seatTypes.length)];

        return new PassengerRailroadCar(netWeight, grossWeight, numberOfPassengers, numberOfSeats, seatType, isConnectedToGrid);
    }

    private static RailroadCar createPostOfficeRailroadCar() {
        double netWeight = (Math.random() * 10000) + 20000;
        double grossWeight = (Math.random() * 10000) + 30000;
        int numberOfMailSlots = (int) (Math.random() * 1000) + 500;
        boolean hasSortingMachine = Math.random() < 0.5;
        boolean isConnectedToGrid = Math.random() < 0.5;

        return new PostOfficeRailroad(netWeight, grossWeight, numberOfMailSlots, hasSortingMachine, isConnectedToGrid);
    }

    private static RailroadCar createBaggageAndMailCar() {
        double netWeight = (Math.random() * 5000) + 10000;
        double grossWeight = (Math.random() * 6000) + 15000;
        int maxBaggageItems = (int) (Math.random() * 500) + 100;
        BaggageHandlingMechanism[] baggageHandlingMechanisms = BaggageHandlingMechanism.values();
        BaggageHandlingMechanism baggageHandlingMechanism = baggageHandlingMechanisms[(int) (Math.random() * baggageHandlingMechanisms.length)];

        return new BaggageAndMailRailroadCar(netWeight, grossWeight, maxBaggageItems, baggageHandlingMechanism);
    }

    private static RailroadCar createRestaurantCar() {
        double netWeight = (Math.random() * 5000) + 10000;
        double grossWeight = (Math.random() * 6000) + 15000;
        int numberOfTables =  (int) (Math.random() * 50) + 20;
        int seatingCapacity = (int) (Math.random() * 200) + 100;
        boolean hasBar = Math.random() < 0.5;
        CuisineType[] cuisineTypes = CuisineType.values();
        CuisineType cuisineType = cuisineTypes[(int) (Math.random() * cuisineTypes.length)];
        boolean isConnectedToGrid = Math.random() < 0.5;

        return new RestaurantRailroadCar(netWeight, grossWeight, numberOfTables, seatingCapacity, hasBar, cuisineType, isConnectedToGrid);
    }

    private static RailroadCar createBasicFreightCar() {
        double netWeight = (Math.random() * 50000) + 100000;
        double grossWeight = (Math.random() * 60000) + 150000;
        Shipper[] shippers = Shipper.values();
        Shipper shipper = shippers[(int) (Math.random() * shippers.length)];
        SecurityInformation[] securityInformations = SecurityInformation.values();
        SecurityInformation securityInformation = securityInformations[(int) (Math.random()) * securityInformations.length];
        int cargoCapacity = (int) (Math.random() * 200000) + 1000000;
        boolean hasVentilationSystem = Math.random() < 0.5;

        return new BasicFreightRailroadCar(netWeight, grossWeight, shipper, securityInformation, cargoCapacity, hasVentilationSystem);
    }

    private static RailroadCar createHeavyFreightCar() {
        double netWeight = (Math.random() * 200000) + 300000;
        double grossWeight = (Math.random() * 300000) + 400000;
        Shipper[] shippers = Shipper.values();
        Shipper shipper = shippers[(int) (Math.random() * shippers.length)];
        SecurityInformation[] securityInformations = SecurityInformation.values();
        SecurityInformation securityInformation = securityInformations[(int) (Math.random()) * securityInformations.length];
        boolean hasSideDoors = Math.random() < 0.5;
        BrakeSystem[] brakeSystems = BrakeSystem.values();
        BrakeSystem brakeSystem = brakeSystems[(int) (Math.random()) * brakeSystems.length];

        return new HeavyFreightRailroadCar(netWeight, grossWeight, shipper, securityInformation, hasSideDoors, brakeSystem);
    }

    private static RailroadCar createRefrigeratedCar() {
        double netWeight = (Math.random() * 2000) + 1000;
        double grossWeight = (Math.random() * 5000) + 10000;
        Shipper[] shippers = Shipper.values();
        Shipper shipper = shippers[(int) (Math.random() * shippers.length)];
        SecurityInformation[] securityInformations = SecurityInformation.values();
        SecurityInformation securityInformation = securityInformations[(int) (Math.random()) * securityInformations.length];
        int cargoCapacity = (int) (Math.random() * 2000) + 10000;
        boolean hasVentilationSystem = Math.random() < 0.5;
        int temperatureMinRange = (int) (Math.random() * 4) + 1;
        int temperatureMaxRange = (int) (Math.random() * 10) + 5;
        boolean hasHumidityControl = Math.random() < 0.5;
        boolean isConnectedToGrid = Math.random() < 0.5;

        return new RefrigeratedRailroadCar(netWeight, grossWeight, shipper, securityInformation, cargoCapacity, hasVentilationSystem, temperatureMinRange, temperatureMaxRange, hasHumidityControl, isConnectedToGrid);
    }

    private static RailroadCar createLiquidMaterialsCar() {
        double netWeight = (Math.random() * 50000) + 110000;
        double grossWeight = (Math.random() * 60000) + 160000;
        Shipper[] shippers = Shipper.values();
        Shipper shipper = shippers[(int) (Math.random() * shippers.length)];
        SecurityInformation[] securityInformations = SecurityInformation.values();
        SecurityInformation securityInformation = securityInformations[(int) (Math.random()) * securityInformations.length];
        int cargoCapacity = (int) (Math.random() * 20000) + 100000;
        boolean hasVentilationSystem = Math.random() < 0.5;
        PumpType[] pumpTypes = PumpType.values();
        PumpType pumpType = pumpTypes[(int) (Math.random() * pumpTypes.length)];
        TankMaterial[] tankMaterials = TankMaterial.values();
        TankMaterial tankMaterial = tankMaterials[(int) (Math.random() * tankMaterials.length)];

        return new LiquidMaterialsRailroadCar(netWeight, grossWeight, shipper, securityInformation, cargoCapacity, hasVentilationSystem, pumpType, tankMaterial);
    }

    private static RailroadCar createGaseousMaterialsCar() {
        double netWeight = (Math.random() * 12000) + 10000;
        double grossWeight = (Math.random() * 20000) + 15000;
        Shipper[] shippers = Shipper.values();
        Shipper shipper = shippers[(int) (Math.random() * shippers.length)];
        SecurityInformation[] securityInformations = SecurityInformation.values();
        SecurityInformation securityInformation = securityInformations[(int) (Math.random()) * securityInformations.length];
        int cargoCapacity = (int) (Math.random() * 21000) + 110000;
        boolean hasVentilationSystem = Math.random() < 0.5;
        boolean hasPressureVessel = Math.random() < 0.5;
        GasType[] gasTypes = GasType.values();
        GasType gasType = gasTypes[(int) (Math.random() * gasTypes.length)];

        return new GaseousMaterialsRailroadCar(netWeight, grossWeight, shipper, securityInformation, cargoCapacity, hasVentilationSystem, hasPressureVessel, gasType);
    }

    private static RailroadCar createExplosivesCar() {
        double netWeight = (Math.random() * 250000) + 100000;
        double grossWeight = (Math.random() * 300000) + 200000;
        Shipper[] shippers = Shipper.values();
        Shipper shipper = shippers[(int) (Math.random() * shippers.length)];
        SecurityInformation[] securityInformations = SecurityInformation.values();
        SecurityInformation securityInformation = securityInformations[(int) (Math.random()) * securityInformations.length];
        boolean hasSideDoors = Math.random() < 0.5;
        BrakeSystem[] brakeSystems = BrakeSystem.values();
        BrakeSystem brakeSystem = brakeSystems[(int) (Math.random()) * brakeSystems.length];
        ExplosiveType[] explosiveTypes = ExplosiveType.values();
        ExplosiveType explosiveType = explosiveTypes[(int) (Math.random()) * explosiveTypes.length];
        LockingMechanism[] lockingMechanisms = LockingMechanism.values();
        LockingMechanism lockingMechanism = lockingMechanisms[(int) (Math.random()) * lockingMechanisms.length];

        return new ExplosivesRailroadCar(netWeight, grossWeight, shipper, securityInformation, hasSideDoors, brakeSystem, explosiveType, lockingMechanism);
    }

    private static RailroadCar createToxicMaterialCar() {
        double netWeight = (Math.random() * 300000) + 100000;
        double grossWeight = (Math.random() * 350000) + 200000;
        Shipper[] shippers = Shipper.values();
        Shipper shipper = shippers[(int) (Math.random() * shippers.length)];
        SecurityInformation[] securityInformations = SecurityInformation.values();
        SecurityInformation securityInformation = securityInformations[(int) (Math.random()) * securityInformations.length];
        boolean hasSideDoors = Math.random() < 0.5;
        BrakeSystem[] brakeSystems = BrakeSystem.values();
        BrakeSystem brakeSystem = brakeSystems[(int) (Math.random()) * brakeSystems.length];
        boolean hasWarningLabels = Math.random() < 0.5;
        HazmatSuit[] hazmatSuits = HazmatSuit.values();
        HazmatSuit hazmatSuit = hazmatSuits[(int) (Math.random() * hazmatSuits.length)];

        return new ToxicMaterialsRailroadCar(netWeight, grossWeight, shipper, securityInformation, hasSideDoors, brakeSystem, hasWarningLabels, hazmatSuit);
    }

    private static RailroadCar createLiquidToxicMaterialCar() {
        double netWeight = (Math.random() * 250000) + 10000;
        double grossWeight = (Math.random() * 300000) + 15000;
        Shipper[] shippers = Shipper.values();
        Shipper shipper = shippers[(int) (Math.random() * shippers.length)];
        SecurityInformation[] securityInformations = SecurityInformation.values();
        SecurityInformation securityInformation = securityInformations[(int) (Math.random()) * securityInformations.length];
        boolean hasSideDoors = Math.random() < 0.5;
        BrakeSystem[] brakeSystems = BrakeSystem.values();
        BrakeSystem brakeSystem = brakeSystems[(int) (Math.random()) * brakeSystems.length];
        boolean hasWarningLabels = Math.random() < 0.5;
        HazmatSuit[] hazmatSuits = HazmatSuit.values();
        HazmatSuit hazmatSuit = hazmatSuits[(int) (Math.random() * hazmatSuits.length)];
        PumpType[] pumpTypes = PumpType.values();
        PumpType pumpType = pumpTypes[(int) (Math.random() * pumpTypes.length)];
        TankMaterial[] tankMaterials = TankMaterial.values();
        TankMaterial tankMaterial = tankMaterials[(int) (Math.random() * tankMaterials.length)];
        boolean isExpenisve = Math.random() < 0.5;
        boolean hasCargoTracking = Math.random() < 0.5;

        return new LiquidToxicMaterialRailroadCar(netWeight, grossWeight, shipper, securityInformation, hasSideDoors, brakeSystem, hasWarningLabels, hazmatSuit, pumpType, tankMaterial, isExpenisve, hasCargoTracking);
    }

}