package generators;

import railwaystation.RailwayStation;
import railwaystation.RailwayStationNetwork;

public class StationsAndConnectionsGenerator {
    private RailwayStationNetwork railwayStationNetwork;

    public StationsAndConnectionsGenerator(RailwayStationNetwork railwayStationNetwork) {
        this.railwayStationNetwork = railwayStationNetwork;
    }

    public RailwayStationNetwork generateNetwork(int numberOfStations) {
        RailwayStationNetwork railwayStationNetwork = new RailwayStationNetwork();
        generateStationsAndConnections(railwayStationNetwork, numberOfStations);
        return railwayStationNetwork;
    }


    private void generateStationsAndConnections(RailwayStationNetwork railwayStationNetwork, int numberOfStations){
        for (int i = 0; i <= numberOfStations; i++) {
            String stationName = generateStationName(i);
            RailwayStation station = new RailwayStation(stationName ,i);
            railwayStationNetwork.addStation(station);
        }

        for (int i = 0; i < numberOfStations; i++) {
            generateRandomConnections(railwayStationNetwork, i, numberOfStations, 5);
        }
    }

    private void generateRandomConnections (RailwayStationNetwork railwayStationNetwork, int stationId, int numberOfStations, int connectionsPerStation) {
        int connections = 0;
        while (connections < connectionsPerStation) {
            int randomId = (int) (Math.random() * numberOfStations) + 1;
            if (randomId != stationId) {
                int distance = (int) (Math.random() * 20) + 1;
                railwayStationNetwork.addConnection(railwayStationNetwork.getStationById(stationId), railwayStationNetwork.getStationById(randomId), distance);
                railwayStationNetwork.addConnection(railwayStationNetwork.getStationById(randomId), railwayStationNetwork.getStationById(stationId), distance);
                connections++;
            }
        }
    }

    private String generateStationName (int stationNumber) {
        return "Station_" + stationNumber;
    }

    public RailwayStationNetwork getRailwayStationNetwork() {
        return railwayStationNetwork;
    }
}

