import generators.StationsAndConnectionsGenerator;
import generators.TrainsetAndCarList;
import generators.TrainsetGenerator;
import menu.*;
import railwaystation.RailwayStation;
import railwaystation.RailwayStationConnection;
import railwaystation.RailwayStationNetwork;
import trainset.Trainset;
import trainset.TrainsetMovement;
import trainset.locomotive.Locomotive;
import trainset.railroadcar.RailroadCar;
import trainset.railroadcar.baggageandmail.BaggageAndMailRailroadCar;
import trainset.railroadcar.baggageandmail.BaggageHandlingMechanism;
import trainset.railroadcar.freight.basicfreight.BasicFreightRailroadCar;
import trainset.railroadcar.freight.basicfreight.gaseousmaterials.GaseousMaterialsRailroadCar;
import trainset.railroadcar.freight.basicfreight.liquidmaterials.LiquidMaterialsRailroadCar;
import trainset.railroadcar.freight.basicfreight.refrigerated.RefrigeratedRailroadCar;
import trainset.railroadcar.freight.heavyfreight.HeavyFreightRailroadCar;
import trainset.railroadcar.freight.heavyfreight.explosives.ExplosivesRailroadCar;
import trainset.railroadcar.freight.heavyfreight.toxicmaterials.ToxicMaterialsRailroadCar;
import trainset.railroadcar.freight.heavyfreight.toxicmaterials.liquidtoxicmaterial.LiquidToxicMaterialRailroadCar;
import trainset.railroadcar.passenger.PassengerRailroadCar;
import trainset.railroadcar.postoffice.PostOfficeRailroad;
import trainset.railroadcar.restaurant.RestaurantRailroadCar;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.*;

public class RailwayApp {
    private int nextRailroadCarId;
    private Map<Integer, RailroadCar> railroadCars;
    private List<Trainset> trainsets;
    private RailwayStationNetwork railwayStationNetwork;
    private Scanner scanner;
    private LocomotiveCreator locomotiveCreator;
    private MenuHandler menuHandler;
    private SpecialActionHandler specialActionHandler;
    private ObjectRemover objectRemover;


    public RailwayApp() {
        this.nextRailroadCarId = 1;
        this.railroadCars = new HashMap<>();
        this.trainsets = new ArrayList<>();
        this.railwayStationNetwork = new RailwayStationNetwork();
        this.scanner = new Scanner(System.in);
        this.locomotiveCreator = new LocomotiveCreator(railwayStationNetwork);
        this.menuHandler = new MenuHandler();
        this.objectRemover = new ObjectRemover(scanner, trainsets, railroadCars, railwayStationNetwork);
    }

    public void runApp() {
        System.out.println("Welcome the Jastrzębski Trainset Management Application!");

        int numberOfStations = 100;
        generateStationsAndConnections(numberOfStations);

        int numberOfTrainsets = 25;
        generateTrainsets(numberOfTrainsets);

        simulateTrainsetMovements(trainsets, railwayStationNetwork);

        Thread appStateThread = new Thread(() -> {
            while (true) {
                try {
                    addAppState();
                    Thread.sleep(5000);
                } catch (InterruptedException e) {
                    System.out.println("AppState thread interrupted");
                }
            }
        });
        appStateThread.start();

        int choice;

        do {
            menuHandler.printMenu();
            choice = readIntInput(1,11);

            switch (choice) {
                case 1:
                    createNewLocomotive();
                    break;
                case 2:
                    createNewRailroadCar();
                    break;
                case 3:
                    createNewRailwayStation();
                    break;
                case 4:
                    createNewConnection();
                    break;
                case 5:
                    handleSpecialAction();
                    break;
                case 6:
                    handleRemoveObject();
                    break;
                case 7:
                    displayReport();
                    break;
                case 8:
                    displayAllTrainsets();
                    break;
                case 9:
                    displayAllRailwayStations();
                    break;
                case 10:
                    System.out.println("Closing the App. Thank you for using the Jastrzębski Trainset Management Application!");
            }
        } while(choice != 10);

        scanner.close();
    }

    private void createNewLocomotive() {
        Locomotive locomotive = locomotiveCreator.createNewLocomotive();
        //Trainset trainset = new Trainset(locomotive);
    }

    private void createNewRailroadCar() {
        RailroadCarCreator railroadCarCreator = new RailroadCarCreator();
        railroadCarCreator.createNewRailroadCar(trainsets);
        railroadCars.putAll(railroadCarCreator.getRailroadCars());
    }

    private void createNewRailwayStation() {
        System.out.println("Enter the name of the new railway station: ");
        String stationName = scanner.next();

        int newStationId = RailwayStation.getNextId();
        RailwayStation newStation = new RailwayStation(stationName, newStationId);
        railwayStationNetwork.addStation(newStation);
    }

    private void createNewConnection() {
        System.out.println("Enter the name of the first railway station: ");
        String stationName1 = scanner.next();
        System.out.println("Enter the name of the second railway station: " );
        String stationName2 = scanner.next();

        RailwayStation station1 = railwayStationNetwork.getStationByName(stationName1);
        RailwayStation station2 = railwayStationNetwork.getStationByName(stationName2);

        if (station1 == null || station2 == null) {
            System.out.println("ERROR: Stations not found");
            return;
        }

        System.out.println("Enter the distance between them: ");
        double distance = scanner.nextDouble();

        railwayStationNetwork.addConnection(station1, station2, distance);
    }

    private void handleSpecialAction() {
        System.out.println("Enter the ID of the railroad car to perform a special action on: ");
        int railroadCarId = readIntInput(0, Integer.MAX_VALUE);
        RailroadCar car = railroadCars.get(railroadCarId);
        if (car != null) {
            SpecialActionHandler handler = new SpecialActionHandler(car,scanner);
            handler.handleSpecialAction(railroadCarId);
        }
        else {
            System.out.println("ERROR: Railroad car not found");
        }
    }

    private void handleRemoveObject() {
        objectRemover.handleRemoveObject();
    }

    private void displayReport() {
        System.out.println("Enter the trainset ID: ");
        int trainsetId = readIntInput(0, Integer.MAX_VALUE);
        scanner.nextLine();

        Trainset trainset = null;
        for (Trainset t : trainsets) {
            if (t.getLocomotive().getId() == trainsetId) {
                trainset = t;
                break;
            }
        }

        if (trainset == null) {
            System.out.println("Trainset not found");
            return;
        }

        Locomotive locomotive = trainset.getLocomotive();
        TrainsetMovement trainsetMovement = new TrainsetMovement(trainset, railwayStationNetwork);

        System.out.println("\nTrainset ID: " + trainset.getLocomotive().getId());
        System.out.println("Home station: "+ locomotive.getHomeStation().getStationName());
        System.out.println("Source station: " + locomotive.getSourceStation().getStationName());
        System.out.println("Destination station: " + locomotive.getDestinationStation().getStationName());
        System.out.println("Speed: " + + (int) locomotive.getSpeed() + " km/h");

        System.out.println("\nRailroad cars: ");
        for (RailroadCar car : trainset.getRailroadCars()) {
            System.out.println("Car ID: " + car.getId());
            System.out.println("Type: " + car.getType());

            if (car instanceof PassengerRailroadCar) {
                displayPassengerCarDetails((PassengerRailroadCar) car);
            } else if (car instanceof PostOfficeRailroad) {
                displayPostOfficeCarDetails((PostOfficeRailroad) car);
            } else if (car instanceof BaggageAndMailRailroadCar) {
                displayBaggageAndMailCarDetails((BaggageAndMailRailroadCar) car);
            } else if (car instanceof RestaurantRailroadCar) {
                displayRestaurantCarDetails((RestaurantRailroadCar) car);
            } else if (car instanceof RefrigeratedRailroadCar) {
                displayRefrigeratedCarDetails((RefrigeratedRailroadCar) car);
            } else if (car instanceof LiquidToxicMaterialRailroadCar) {
                displayLiquidToxicMaterialCarDetails((LiquidToxicMaterialRailroadCar) car);
            } else if (car instanceof LiquidMaterialsRailroadCar) {
                displayLiquidMaterialsCarDetails((LiquidMaterialsRailroadCar) car);
            } else if (car instanceof GaseousMaterialsRailroadCar) {
                displayGaseousMaterialsCarDetails((GaseousMaterialsRailroadCar) car);
            } else if (car instanceof ExplosivesRailroadCar) {
                displayExplosivesCarDetails((ExplosivesRailroadCar) car);
            } else if (car instanceof ToxicMaterialsRailroadCar) {
                displayToxicMaterialsCarDetails((ToxicMaterialsRailroadCar) car);
            } else if (car instanceof BasicFreightRailroadCar) {
                displayBasicFreightCarDetails((BasicFreightRailroadCar) car);
            } else if (car instanceof HeavyFreightRailroadCar) {
                displayHeavyFreightCarDetails((HeavyFreightRailroadCar) car);
            } else {
                System.out.println("Unknown type ");
            }
        }

        double sumGrossWeight = 0.0;
        for (RailroadCar car : trainset.getRailroadCars()) {
            sumGrossWeight += car.getGrossWeight();
        }

        System.out.println("Total gross weight of all the railroad cars in the trainset: " + (int) sumGrossWeight + " kg");
        System.out.println("Maximum weight a locomotive can carry: " + (int) locomotive.getMaxWeightOfLoad() + " kg");
    }

    private void displayAllTrainsets() {
        System.out.println("All trainsets: ");

        for (Trainset trainset : trainsets) {
            System.out.println("Trainset ID: " + trainset.getLocomotive().getId());
            System.out.print("Railroad car IDs: ");
            for (RailroadCar car : trainset.getRailroadCars()) {
                System.out.print(car.getId() + " ");
            }
            System.out.println("\n");
        }
    }

    private void displayAllRailwayStations() {
        List<RailwayStation> stations = railwayStationNetwork.getStations();

        for (RailwayStation station : stations) {
            System.out.println("Station ID: " + station.getId());
            System.out.println("Station Name: " + station.getStationName());

            List<RailwayStationConnection> connections = station.getConnections();
            System.out.println("Connections:");
            for (RailwayStationConnection connection : connections) {
                System.out.println(" - To " + connection.getDestination().getStationName() + " , Distance: " + connection.getDistance());
            }
            System.out.println();
        }
    }

    private int getNextRailroadCarId() {
        return nextRailroadCarId++;
    }
    private void generateTrainsets(int numberOfTrainsets) {
        TrainsetAndCarList generated = TrainsetGenerator.generateTrainsets(numberOfTrainsets, railwayStationNetwork);
        trainsets = generated.getTrainsets();

        for (RailroadCar car : generated.getRailroadCars()) {
            railroadCars.put(car.getId(), car);
        }
    }

    private void generateStationsAndConnections(int numberOfStations) {
        StationsAndConnectionsGenerator stationsAndConnectionsGenerator = new StationsAndConnectionsGenerator(railwayStationNetwork);
        railwayStationNetwork = stationsAndConnectionsGenerator.generateNetwork(numberOfStations);
    }

    private void simulateTrainsetMovements(List<Trainset> trainsets, RailwayStationNetwork railwayStationNetwork) {
        for (Trainset trainset : trainsets) {
            TrainsetMovement movement = new TrainsetMovement(trainset, railwayStationNetwork);
            Thread movementThread = new Thread(movement);
            movementThread.start();
        }
    }

    private int readIntInput(int min, int max) {
        int choice = -1;
        while (choice < min || choice > max) {
            try {
                System.out.println("Enter your choice: ");
                choice = scanner.nextInt();
                if (choice < min || choice > max) {
                    System.out.println("ERROR: Please enter a number between " + min + " and " + max + ".");
                }
            } catch (InputMismatchException e) {
                System.out.println("ERROR: Please enter a number.");
                scanner.next();
            }
        }
        return choice;
    }

    private void displayPassengerCarDetails(PassengerRailroadCar passengerRailroadCar) {
        System.out.println("Net weight: " + (int) passengerRailroadCar.getNetWeight() + " kg");
        System.out.println("Gross weight: " + (int) passengerRailroadCar.getGrossWeight() + " kg");
        System.out.println("Number of passengers: " + passengerRailroadCar.getNumberOfPassengers());
        System.out.println("Number of seats: " + passengerRailroadCar.getNumberOfSeats());
        System.out.println("Seat type: " + passengerRailroadCar.getSeatType());
        System.out.println("Is connected to grid: " + passengerRailroadCar.isConnected() + "\n");
    }

    private void displayPostOfficeCarDetails(PostOfficeRailroad postOfficeRailroadcar) {
        System.out.println("Net weight: " + (int) postOfficeRailroadcar.getNetWeight() + " kg");
        System.out.println("Gross weight: " + (int) postOfficeRailroadcar.getGrossWeight() + " kg");
        System.out.println("Number of mail slots: " + postOfficeRailroadcar.getNumberOfMailSlots());
        System.out.println("Has sorting machine: " + postOfficeRailroadcar.isHasSortingMachine());
        System.out.println("Is connected to grid: " + postOfficeRailroadcar.isConnected() + "\n");
    }

    private void displayBaggageAndMailCarDetails(BaggageAndMailRailroadCar baggageAndMailRailroadCar) {
        System.out.println("Net weight: " + (int) baggageAndMailRailroadCar.getNetWeight() + " kg");
        System.out.println("Gross weight: " + (int) baggageAndMailRailroadCar.getGrossWeight() + " kg");
        System.out.println("Max baggage items: " + (int) baggageAndMailRailroadCar.getMaxBaggageItems());
        System.out.println("Baggage handling mechanism: " + baggageAndMailRailroadCar.getBaggageHandlingMechanism() + "\n");
    }

    private void displayRestaurantCarDetails(RestaurantRailroadCar restaurantRailroadCar) {
        System.out.println("Net weight: " + (int) restaurantRailroadCar.getNetWeight() + " kg");
        System.out.println("Gross weight: " + (int) restaurantRailroadCar.getGrossWeight() + " kg");
        System.out.println("Number of tables: " + restaurantRailroadCar.getNumberOfTables());
        System.out.println("Seating capacity: " + restaurantRailroadCar.getSeatingCapacity());
        System.out.println("Has bar: " + restaurantRailroadCar.isHasBar());
        System.out.println("Cuisine type: " + restaurantRailroadCar.getCuisineType());
        System.out.println("Is connected to grid: " + restaurantRailroadCar.isConnected() + "\n");
    }

    private void displayBasicFreightCarDetails(BasicFreightRailroadCar basicFreightRailroadCar) {
        System.out.println("Net weight: " + (int) basicFreightRailroadCar.getNetWeight() + " kg");
        System.out.println("Gross weight: " + (int) basicFreightRailroadCar.getGrossWeight() + " kg");
        System.out.println("Shipper: " + basicFreightRailroadCar.getShipper());
        System.out.println("Security information: " + basicFreightRailroadCar.getSecurityInformation());
        System.out.println("Cargo capacity: " + basicFreightRailroadCar.getCargoCapacity());
        System.out.println("Has ventilation system: " + basicFreightRailroadCar.isHasVentilationSystem() + "\n");
    }

    private void displayHeavyFreightCarDetails(HeavyFreightRailroadCar heavyFreightRailroadCar) {
        System.out.println("Net weight: " + (int) heavyFreightRailroadCar.getNetWeight() + " kg");
        System.out.println("Gross weight: " + (int) heavyFreightRailroadCar.getGrossWeight() + " kg");
        System.out.println("Shipper: " + heavyFreightRailroadCar.getShipper());
        System.out.println("Security information: " + heavyFreightRailroadCar.getSecurityInformation());
        System.out.println("Has side doors: " + heavyFreightRailroadCar.isHasSideDoors());
        System.out.println("Brake system: " + heavyFreightRailroadCar.getBrakeSystem() + "\n");
    }

    private void displayRefrigeratedCarDetails(RefrigeratedRailroadCar refrigeratedRailroadCar) {
        System.out.println("Net weight: " + (int) refrigeratedRailroadCar.getNetWeight() + " kg");
        System.out.println("Gross weight: " + (int) refrigeratedRailroadCar.getGrossWeight() + " kg");
        System.out.println("Shipper: " + refrigeratedRailroadCar.getShipper());
        System.out.println("Security information: " + refrigeratedRailroadCar.getSecurityInformation());
        System.out.println("Cargo capacity: " + refrigeratedRailroadCar.getCargoCapacity());
        System.out.println("Has ventilation system: " + refrigeratedRailroadCar.isHasVentilationSystem());
        System.out.println("Temperature min range: " + refrigeratedRailroadCar.getTemperatureMinRange());
        System.out.println("Temperature max range: " + refrigeratedRailroadCar.getTemperatureMaxRange());
        System.out.println("Has humidity control: " + refrigeratedRailroadCar.isHasHumidityControl());
        System.out.println("Is connected to grid: " + refrigeratedRailroadCar.isConnected() + "\n");
    }

    private void displayLiquidMaterialsCarDetails(LiquidMaterialsRailroadCar liquidMaterialsRailroadCar) {
        System.out.println("Net weight: " + (int) liquidMaterialsRailroadCar.getNetWeight() + " kg");
        System.out.println("Gross weight: " + (int) liquidMaterialsRailroadCar.getGrossWeight() + " kg");
        System.out.println("Shipper: " + liquidMaterialsRailroadCar.getShipper());
        System.out.println("Security information: " + liquidMaterialsRailroadCar.getSecurityInformation());
        System.out.println("Cargo capacity: " + liquidMaterialsRailroadCar.getCargoCapacity());
        System.out.println("Has ventilation system: " + liquidMaterialsRailroadCar.isHasVentilationSystem());
        System.out.println("Pump type: " + liquidMaterialsRailroadCar.getPumpType());
        System.out.println("Tank material: " + liquidMaterialsRailroadCar.getTankMaterial() + "\n");
    }

    private void displayGaseousMaterialsCarDetails(GaseousMaterialsRailroadCar gaseousMaterialsRailroadCar) {
        System.out.println("Net weight: " + (int) gaseousMaterialsRailroadCar.getNetWeight() + " kg");
        System.out.println("Gross weight: " + (int) gaseousMaterialsRailroadCar.getGrossWeight() + " kg");
        System.out.println("Shipper: " + gaseousMaterialsRailroadCar.getShipper());
        System.out.println("Security information: " + gaseousMaterialsRailroadCar.getSecurityInformation());
        System.out.println("Cargo capacity: " + gaseousMaterialsRailroadCar.getCargoCapacity());
        System.out.println("Has ventilation system: " + gaseousMaterialsRailroadCar.isHasVentilationSystem());
        System.out.println("Has pressure vessel: " + gaseousMaterialsRailroadCar.isHasPressureVessel());
        System.out.println("Gas type: " + gaseousMaterialsRailroadCar.getGasType() + "\n");
    }

    private void displayExplosivesCarDetails(ExplosivesRailroadCar explosivesRailroadCar) {
        System.out.println("Net weight: " + (int) explosivesRailroadCar.getNetWeight() + " kg");
        System.out.println("Gross weight: " + (int) explosivesRailroadCar.getGrossWeight() + " kg");
        System.out.println("Shipper: " + explosivesRailroadCar.getShipper());
        System.out.println("Security information: " + explosivesRailroadCar.getSecurityInformation());
        System.out.println("Has side doors: " + explosivesRailroadCar.isHasSideDoors());
        System.out.println("Brake system: " + explosivesRailroadCar.getBrakeSystem());
        System.out.println("Explosive type: " + explosivesRailroadCar.getExplosiveType());
        System.out.println("Locking mechanism: " + explosivesRailroadCar.getLockingMechanism() + "\n");
    }

    private void displayToxicMaterialsCarDetails(ToxicMaterialsRailroadCar toxicMaterialsRailroadCar) {
        System.out.println("Net weight: " + (int) toxicMaterialsRailroadCar.getNetWeight() + " kg");
        System.out.println("Gross weight: " + (int) toxicMaterialsRailroadCar.getGrossWeight() + " kg");
        System.out.println("Shipper: " + toxicMaterialsRailroadCar.getShipper());
        System.out.println("Security information: " + toxicMaterialsRailroadCar.getSecurityInformation());
        System.out.println("Has side doors: " + toxicMaterialsRailroadCar.isHasSideDoors());
        System.out.println("Brake system: " + toxicMaterialsRailroadCar.getBrakeSystem());
        System.out.println("Has warning labels: " + toxicMaterialsRailroadCar.isHasWarningLabels());
        System.out.println("Hazmat suit required type: " + toxicMaterialsRailroadCar.getHazmatSuit() + "\n");
    }

    private void displayLiquidToxicMaterialCarDetails(LiquidToxicMaterialRailroadCar liquidToxicMaterialRailroadCar) {
        System.out.println("Net weight: " + (int) liquidToxicMaterialRailroadCar.getNetWeight() + " kg");
        System.out.println("Gross weight: " + (int) liquidToxicMaterialRailroadCar.getGrossWeight() + " kg");
        System.out.println("Shipper: " + liquidToxicMaterialRailroadCar.getShipper());
        System.out.println("Security information: " + liquidToxicMaterialRailroadCar.getShipper());
        System.out.println("Has side doors: " + liquidToxicMaterialRailroadCar.isHasSideDoors());
        System.out.println("Brake system: " + liquidToxicMaterialRailroadCar.getBrakeSystem());
        System.out.println("Has warning labels: " + liquidToxicMaterialRailroadCar.isHasSideDoors());
        System.out.println("Hazmat suit required type: " + liquidToxicMaterialRailroadCar.getBrakeSystem());
        System.out.println("Pump type: " + liquidToxicMaterialRailroadCar.getPumpType());
        System.out.println("Tank material: " + liquidToxicMaterialRailroadCar.getTankMaterial());
        System.out.println("Is expensive: " + liquidToxicMaterialRailroadCar.isExpensive());
        System.out.println("Has cargo tracking system: " + liquidToxicMaterialRailroadCar.isHasCargoTracking() + "\n");
    }

    public synchronized void addAppState() {
        Map<Trainset, Double> trainetRouteLengths = new HashMap<>();
        for (Trainset trainset : trainsets) {
            double routeLength = 0.0;
            RailwayStation sourceStation = trainset.getLocomotive().getSourceStation();
            RailwayStation destinationStation = trainset.getLocomotive().getDestinationStation();

            for (RailwayStationConnection connection : sourceStation.getConnections()) {
                if (connection.getDestination().equals(destinationStation)) {
                    routeLength += connection.getDistance();
                    break;
                }
            }
            trainetRouteLengths.put(trainset, routeLength);
        }

        trainsets.sort((a,b) -> Double.compare(trainetRouteLengths.get(b), trainetRouteLengths.get(a)));

        for (Trainset trainset : trainsets) {
            trainset.sortRailroadCarsByWeight();
        }

        try (BufferedWriter writer = new BufferedWriter(new FileWriter("AppState.txt"))) {
            for (Trainset trainset : trainsets) {
                writer.write(trainset.toString());
                writer.newLine();
            }
        } catch (IOException e) {
            System.out.println("ERROR: " + e.getMessage());
        }
    }
}