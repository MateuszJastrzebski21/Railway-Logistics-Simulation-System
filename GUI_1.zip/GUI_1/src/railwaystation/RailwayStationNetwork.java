package railwaystation;

import java.util.*;

public class RailwayStationNetwork {
    private Map<Integer, RailwayStation> stations;
    private List<RailwayStationConnection> connections;

    public RailwayStationNetwork() {
        this.stations = new HashMap<>();
        this.connections = new ArrayList<>();
    }

    public void addStation(RailwayStation station) {
        stations.put(station.getId(), station);
    }

    public void addConnection(RailwayStation source, RailwayStation destination, double distance) {
        RailwayStationConnection connection = new RailwayStationConnection(source, destination, distance);
        source.addConnection(connection);
        connections.add(connection);
    }

    public double getDistanceBetweenStations(RailwayStation station1, RailwayStation station2) {
        for (RailwayStationConnection connection : station1.getConnections()) {
            if (connection.getDestination().equals(station2)) {
                return connection.getDistance();
            }
        }

        return -1.0;
    }

    public List<RailwayStation> findShortestRoute(int sourceId, int destinationId) {
        RailwayStation source = stations.get(sourceId);
        RailwayStation destination = stations.get(destinationId);

        if (source == null || destination == null) {
            return null;
        }

        Map<RailwayStation, Double> distances = new HashMap<>();
        Map<RailwayStation, RailwayStation> previousStations = new HashMap<>();
        Set<RailwayStation> unvisitedStations = new HashSet<>();

        for (RailwayStation station : stations.values()) {
            distances.put(station, Double.MAX_VALUE);
            unvisitedStations.add(station);
        }

        distances.put(source, 0.0);

        while (!unvisitedStations.isEmpty()) {
            RailwayStation current = getStationWithShortestDistance(distances, unvisitedStations);
            unvisitedStations.remove(current);

            if(current.equals(destination)) {
                break;
            }

            for (RailwayStationConnection connection : current.getConnections()) {
                RailwayStation neighbor = connection.getDestination();
                double newDistance = distances.get(current) + connection.getDistance();

                if (newDistance < distances.get(neighbor)) {
                    distances.put(neighbor, newDistance);
                    previousStations.put(neighbor, current);
                }
            }
        }

        List<RailwayStation> reversedPath = new ArrayList<>();
        RailwayStation station = destination;

        while (station != null) {
            reversedPath.add(station);
            station = previousStations.get(station);
        }

        List<RailwayStation> path = new ArrayList<>();
        for (int i = reversedPath.size() - 1; i >= 0; i--) {
            path.add(reversedPath.get(i));
        }

        return path;
    }

    private RailwayStation getStationWithShortestDistance(Map<RailwayStation, Double> distances, Set<RailwayStation> unvisitedStations) {
        RailwayStation shortestStation = null;
        double shortestDistance = Double.MAX_VALUE;

        for (RailwayStation station : unvisitedStations) {
            double distance = distances.get(station);

            if(distance < shortestDistance) {
                shortestDistance = distance;
                shortestStation = station;
            }
        }

        return shortestStation;
    }

    public RailwayStation getStationByName(String name) {
        for (RailwayStation station : stations.values()) {
            if (station.getStationName().equals(name)) {
                return station;
            }
        }
        return null;
    }

    public RailwayStation getStationById(int id) {
        return stations.get(id);
    }

    public List<RailwayStation> getStations() {
        List<RailwayStation> stationList = new ArrayList<>(stations.values());
        return stationList;
    }

    public List<RailwayStationConnection> getConnections() {
        return connections;
    }
}
