package railwaystation;

public class RailwayStationConnection {
    private RailwayStation source;
    private RailwayStation destination;
    private double distance;

    public RailwayStationConnection(RailwayStation source, RailwayStation destination, double distance) {
        this.source = source;
        this.destination = destination;
        this.distance = distance;
    }

    public RailwayStation getSource() {
        return source;
    }

    public void setSource(RailwayStation source) {
        this.source = source;
    }

    public RailwayStation getDestination() {
        return destination;
    }

    public void setDestination(RailwayStation destination) {
        this.destination = destination;
    }

    public double getDistance() {
        return distance;
    }

    public void setDistance(double distance) {
        this.distance = distance;
    }
}
