package railwaystation;

import java.util.ArrayList;
import java.util.List;

public class RailwayStation {
    private static int nextId = 1;
    private String stationName;
    private int id;
    private List<RailwayStationConnection> connections;

    public RailwayStation(String stationName, int id) {
        this.stationName = stationName;
        this.id = id;
        this.connections = new ArrayList<>();
    }

    public static int getNextId() {
        return nextId++;
    }

    public String getStationName() {
        return stationName;
    }

    public void setStationName(String stationName) {
        this.stationName = stationName;
    }

    public int getId() {
        return id;
    }

    public List<RailwayStationConnection> getConnections() {
        return connections;
    }

    public void addConnection(RailwayStationConnection connection) {
        this.connections.add(connection);
    }

    public void removeConnection(RailwayStationConnection connection) {
        this.connections.remove(connection);
    }
}
