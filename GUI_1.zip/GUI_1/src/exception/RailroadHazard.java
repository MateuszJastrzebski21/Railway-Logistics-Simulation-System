package exception;

import trainset.Trainset;

public class RailroadHazard extends Exception{
    private Trainset trainset;

    public RailroadHazard(Trainset trainset) {
        super("Railroad Hazard! Trainset exceeded 200 km/h! \n"
                + "Locomotive ID: " + trainset.getLocomotive().getId()
                + "\nName: " + trainset.getLocomotive().getName()
                + "\nSource Station: " + trainset.getSourceStation().getStationName()
                + "\nDestination Station: " + trainset.getDestinationStation().getStationName());
        this.trainset = trainset;
    }

    public Trainset getTrainset() {
        return trainset;
    }

    public void handleRailroadHazard() {
        System.out.println("Trainset is being slowed down to 150 km/h...\n");
        trainset.getLocomotive().setSpeed(150);
    }
}
