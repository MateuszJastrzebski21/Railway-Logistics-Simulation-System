package trainset;

import exception.RailroadHazard;
import railwaystation.RailwayStation;
import railwaystation.RailwayStationNetwork;

import java.util.List;
import java.util.Random;

public class TrainsetMovement implements Runnable {
    public Trainset trainset;
    public RailwayStationNetwork railwayStationNetwork;
    private double remainingDistance = -1;
    public double currentPosition;
    private List<RailwayStation> shortestRoute;

    public TrainsetMovement(Trainset trainset, RailwayStationNetwork railwayStationNetwork) {
        this.trainset = trainset;
        this.railwayStationNetwork = railwayStationNetwork;
    }

    @Override
    public void run() {
        try {
            RailwayStation home = trainset.getHomeStation();
            RailwayStation source = trainset.getSourceStation();
            RailwayStation destination = trainset.getDestinationStation();

            while (true) {
                moveTrainset(home, source);
                moveTrainset(source, destination);
                moveTrainset(destination, home);
            }
        } catch (InterruptedException e) {
            System.out.println("Trainset interrupted: " + e.getMessage());
        }
    }


    private synchronized void moveTrainset(RailwayStation from, RailwayStation to) throws InterruptedException{
        List<RailwayStation> shortestRoute = railwayStationNetwork.findShortestRoute(from.getId(), to.getId());

        if (shortestRoute == null || shortestRoute.isEmpty()) {
            return;
        }

        for (RailwayStation station : shortestRoute) {
            //System.out.println(station.getStationName());
        }

        for (int i = 0; i < shortestRoute.size() - 1; i++) {
            RailwayStation currentStation = shortestRoute.get(i);
            RailwayStation nextStation = shortestRoute.get(i + 1);

            double distance = railwayStationNetwork.getDistanceBetweenStations(currentStation, nextStation);
            int timeToNextStation = (int)((distance / trainset.getLocomotive().getSpeed()) * 3600 * 1000);

            trainset.getLocomotive().setCurrentStation(currentStation);
            remainingDistance = distance;
            currentPosition = 0;


            int elapsedTime = 0;

            while (elapsedTime < timeToNextStation) {
                trainset.getLocomotive().updateSpeed();
                if (trainset.getLocomotive().getSpeed() > 200) {
                    try {
                        throw new RailroadHazard(trainset);
                    } catch (RailroadHazard e) {
                        System.out.println(e.getMessage());
                        e.handleRailroadHazard();
                    }
                }
                Thread.sleep(1000);
                elapsedTime += 1000;
                currentPosition += trainset.getLocomotive().getSpeed() / 3600.0;

                synchronized (this) {
                    remainingDistance = distance - currentPosition;
                }

                if (currentPosition >= distance) {
                    Thread.sleep(2000);
                }

                if (nextStation.equals(to) && currentPosition >= distance) {
                    Thread.sleep(30000);
                }

                //System.out.println("Distance: " + distance);
                //System.out.println("Current Position: " + currentPosition);
                //System.out.println("Remaining Distance: " + remainingDistance);
            }

            trainset.getLocomotive().setCurrentStation(nextStation);
        }
    }

    public synchronized double getCurrentPosition() {
        return currentPosition;
    }

    public RailwayStation getNextStation() {
        RailwayStation currentStation = trainset.getLocomotive().getCurrentStation();

        for (int i = 0; i < shortestRoute.size() - 1; i++) {
            if (shortestRoute.get(i).equals(currentStation)) {
                return shortestRoute.get(i + 1);
            }
        }
        return null;
    }


    public synchronized double getRemainingDistance() {
        return remainingDistance;
    }

    private synchronized void updateRemainingDistance(double newRemainingDistance) {
        remainingDistance = newRemainingDistance;
    }

    public Trainset getTrainset() {
        return this.trainset;
    }
}
