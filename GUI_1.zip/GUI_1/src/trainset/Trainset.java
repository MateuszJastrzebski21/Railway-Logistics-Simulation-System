package trainset;

import railwaystation.RailwayStation;
import railwaystation.RailwayStationNetwork;
import trainset.locomotive.Locomotive;
import trainset.railroadcar.RailroadCar;
import trainset.railroadcar.baggageandmail.BaggageAndMailRailroadCar;
import trainset.railroadcar.freight.basicfreight.BasicFreightRailroadCar;
import trainset.railroadcar.freight.basicfreight.gaseousmaterials.GaseousMaterialsRailroadCar;
import trainset.railroadcar.freight.basicfreight.liquidmaterials.LiquidMaterialsRailroadCar;
import trainset.railroadcar.freight.basicfreight.refrigerated.RefrigeratedRailroadCar;
import trainset.railroadcar.freight.heavyfreight.HeavyFreightRailroadCar;
import trainset.railroadcar.freight.heavyfreight.explosives.ExplosivesRailroadCar;
import trainset.railroadcar.freight.heavyfreight.toxicmaterials.ToxicMaterialsRailroadCar;
import trainset.railroadcar.freight.heavyfreight.toxicmaterials.liquidtoxicmaterial.LiquidToxicMaterialRailroadCar;
import trainset.railroadcar.passenger.PassengerRailroadCar;
import trainset.railroadcar.postoffice.PostOfficeRailroad;
import trainset.railroadcar.restaurant.RestaurantRailroadCar;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class Trainset {
    private Locomotive locomotive;
    private List<RailroadCar> railroadCars;
    private RailwayStation homeStation;
    private RailwayStation sourceStation;
    private RailwayStation destinationStation;
    private TrainsetMovement trainsetMovement;

    public Trainset(Locomotive locomotive) {
        this.locomotive = locomotive;
        this.railroadCars = new ArrayList<>();
        this.homeStation = locomotive.getHomeStation();
        this.sourceStation = locomotive.getSourceStation();
        this.destinationStation = locomotive.getDestinationStation();
    }

    public Locomotive getLocomotive() {
        return locomotive;
    }

    public void setLocomotive(Locomotive locomotive) {
        this.locomotive = locomotive;
    }

    public List<RailroadCar> getRailroadCars() {
        return railroadCars;
    }

    public RailwayStation getHomeStation() {
        return homeStation;
    }

    public void setHomeStation(RailwayStation homeStation) {
        this.homeStation = homeStation;
    }

    public RailwayStation getSourceStation() {
        return sourceStation;
    }

    public void setSourceStation(RailwayStation sourceStation) {
        this.sourceStation = sourceStation;
    }

    public RailwayStation getDestinationStation() {
        return destinationStation;
    }

    public void setDestinationStation (RailwayStation destinationStation) {
        this.destinationStation = destinationStation;
    }

    public void startTrainsetMovement (RailwayStationNetwork railwayStationNetwork) {
        this.trainsetMovement = new TrainsetMovement(this, railwayStationNetwork);
        Thread trainsetMovementThread = new Thread(trainsetMovement);
        trainsetMovementThread.start();
    }

    private double getGrossWeight() {
        double totalWeight = 0;
        for (RailroadCar car : railroadCars) {
            totalWeight += car.getGrossWeight();
        }
        return totalWeight;
    }

    public void addRailroadCar(RailroadCar railroadCar) throws Exception {
        int totalNumOfCars = railroadCars.size();
        double totalWeightOfCars = getGrossWeight();

        if (totalNumOfCars + 1 > locomotive.getMaxNumOfCars()) {
            throw new Exception("ERROR: Maximum number of railroad cars");
        }

        if (totalWeightOfCars + railroadCar.getGrossWeight() > locomotive.getMaxWeightOfLoad()) {
            throw new Exception("ERROR: Maximum weight of transported loas");
        }

        railroadCars.add(railroadCar);
    }

    public void removeRailroadCar (int id) {
        for (int i = 0; i < railroadCars.size(); i++) {
            if (railroadCars.get(i).getId() == id) {
                railroadCars.remove(i);
                break;
            }
        }
    }

    public boolean containsCar (RailroadCar car) {
        return railroadCars.contains(car);
    }

    public boolean isAtStation() {
        return locomotive.isAtStation();
    }

    public boolean isCarAtStation (RailroadCar car) {
        return isAtStation() && containsCar(car);
    }

    public RailroadCar findCarById (int id) {
        for (RailroadCar car : railroadCars) {
            if (car.getId() == id) {
                return car;
            }
        }
        return null;
    }

    public TrainsetMovement getTrainsetMovement() {
        return trainsetMovement;
    }

    public void setTrainsetMovement (TrainsetMovement trainsetMovement) {
        this.trainsetMovement = trainsetMovement;
    }

    public void sortRailroadCarsByWeight() {
        railroadCars.sort(Comparator.comparingDouble(RailroadCar :: getGrossWeight));
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();

        sb.append("\nTrainset ID: ").append(getLocomotive().getId()).append("\n");
        sb.append("Home station: " ).append(locomotive.getHomeStation().getStationName()).append("\n");
        sb.append("Source station: " ).append(locomotive.getSourceStation().getStationName()).append("\n");
        sb.append("Destination station: " ).append(locomotive.getDestinationStation().getStationName()).append("\n");
        sb.append("Speed: ").append((int) locomotive.getSpeed()).append(" km/h").append("\n");

        sb.append("\nRailroad cars: \n");
        for (RailroadCar car : getRailroadCars()) {
            sb.append("Car ID: ").append(car.getId()).append("\n");
            sb.append("Type:").append(car.getType()).append("\n");

            /*if (car instanceof PassengerRailroadCar) {
                sb.append(displayPassengerCarDetails((PassengerRailroadCar) car));
            } else if (car instanceof PostOfficeRailroad) {
                sb.append(displayPostOfficeCarDetails((PostOfficeRailroad) car));
            } else if (car instanceof BaggageAndMailRailroadCar) {
                sb.append(displayBaggageAndMailCarDetails((BaggageAndMailRailroadCar) car));
            } else if (car instanceof RestaurantRailroadCar) {
                sb.append(displayRestaurantCarDetails((RestaurantRailroadCar) car));
            } else if (car instanceof RefrigeratedRailroadCar) {
                sb.append(displayRefrigeratedCarDetails((RefrigeratedRailroadCar) car));
            } else if (car instanceof LiquidToxicMaterialRailroadCar) {
                sb.append(displayLiquidToxicMaterialCarDetails((LiquidToxicMaterialRailroadCar) car));
            } else if (car instanceof LiquidMaterialsRailroadCar) {
                sb.append(displayLiquidMaterialsCarDetails((LiquidMaterialsRailroadCar) car));
            } else if (car instanceof GaseousMaterialsRailroadCar) {
                sb.append(displayGaseousMaterialsCarDetails((GaseousMaterialsRailroadCar) car));
            } else if (car instanceof ExplosivesRailroadCar) {
                sb.append(displayExplosivesCarDetails((ExplosivesRailroadCar) car));
            } else if (car instanceof ToxicMaterialsRailroadCar) {
                sb.append(displayToxicMaterialsCarDetails((ToxicMaterialsRailroadCar) car));
            } else if (car instanceof BasicFreightRailroadCar) {
                sb.append(displayBasicFreightCarDetails((BasicFreightRailroadCar) car));
            } else if (car instanceof HeavyFreightRailroadCar) {
                sb.append(displayHeavyFreightCarDetails((HeavyFreightRailroadCar) car));
            } else {
                sb.append("Unknown type").append("\n");
            }
        }*/



        double sumGrossWeight = 0.0;
        for (RailroadCar railroadCar : this.getRailroadCars()) {
            sumGrossWeight += railroadCar.getGrossWeight();
        }

        sb.append("Total gross weight of all the railroad cars in the trainset: " + (int) sumGrossWeight + " kg").append("\n");
        sb.append("Maximum weight a locomotive can carry: " + (int) locomotive.getMaxWeightOfLoad() + " kg").append("\n");


        }
        return sb.toString();
    }

    /*private void displayPassengerCarDetails(PassengerRailroadCar passengerRailroadCar) {
        System.out.println("Net weight: " + (int) passengerRailroadCar.getNetWeight() + " kg");
        System.out.println("Gross weight: " + (int) passengerRailroadCar.getGrossWeight() + " kg");
        System.out.println("Number of passengers: " + passengerRailroadCar.getNumberOfPassengers());
        System.out.println("Number of seats: " + passengerRailroadCar.getNumberOfSeats());
        System.out.println("Seat type: " + passengerRailroadCar.getSeatType());
        System.out.println("Is connected to grid: " + passengerRailroadCar.isConnected() + "\n");
    }

    private void displayPostOfficeCarDetails(PostOfficeRailroad postOfficeRailroadcar) {
        System.out.println("Net weight: " + (int) postOfficeRailroadcar.getNetWeight() + " kg");
        System.out.println("Gross weight: " + (int) postOfficeRailroadcar.getGrossWeight() + " kg");
        System.out.println("Number of mail slots: " + postOfficeRailroadcar.getNumberOfMailSlots());
        System.out.println("Has sorting machine: " + postOfficeRailroadcar.isHasSortingMachine());
        System.out.println("Is connected to grid: " + postOfficeRailroadcar.isConnected() + "\n");
    }

    private void displayBaggageAndMailCarDetails(BaggageAndMailRailroadCar baggageAndMailRailroadCar) {
        System.out.println("Net weight: " + (int) baggageAndMailRailroadCar.getNetWeight() + " kg");
        System.out.println("Gross weight: " + (int) baggageAndMailRailroadCar.getGrossWeight() + " kg");
        System.out.println("Max baggage items: " + (int) baggageAndMailRailroadCar.getMaxBaggageItems());
        System.out.println("Baggage handling mechanism: " + baggageAndMailRailroadCar.getBaggageHandlingMechanism() + "\n");
    }

    private void displayRestaurantCarDetails(RestaurantRailroadCar restaurantRailroadCar) {
        System.out.println("Net weight: " + (int) restaurantRailroadCar.getNetWeight() + " kg");
        System.out.println("Gross weight: " + (int) restaurantRailroadCar.getGrossWeight() + " kg");
        System.out.println("Number of tables: " + restaurantRailroadCar.getNumberOfTables());
        System.out.println("Seating capacity: " + restaurantRailroadCar.getSeatingCapacity());
        System.out.println("Has bar: " + restaurantRailroadCar.isHasBar());
        System.out.println("Cuisine type: " + restaurantRailroadCar.getCuisineType());
        System.out.println("Is connected to grid: " + restaurantRailroadCar.isConnected() + "\n");
    }

    private void displayBasicFreightCarDetails(BasicFreightRailroadCar basicFreightRailroadCar) {
        System.out.println("Net weight: " + (int) basicFreightRailroadCar.getNetWeight() + " kg");
        System.out.println("Gross weight: " + (int) basicFreightRailroadCar.getGrossWeight() + " kg");
        System.out.println("Shipper: " + basicFreightRailroadCar.getShipper());
        System.out.println("Security information: " + basicFreightRailroadCar.getSecurityInformation());
        System.out.println("Cargo capacity: " + basicFreightRailroadCar.getCargoCapacity());
        System.out.println("Has ventilation system: " + basicFreightRailroadCar.isHasVentilationSystem() + "\n");
    }

    private void displayHeavyFreightCarDetails(HeavyFreightRailroadCar heavyFreightRailroadCar) {
        System.out.println("Net weight: " + (int) heavyFreightRailroadCar.getNetWeight() + " kg");
        System.out.println("Gross weight: " + (int) heavyFreightRailroadCar.getGrossWeight() + " kg");
        System.out.println("Shipper: " + heavyFreightRailroadCar.getShipper());
        System.out.println("Security information: " + heavyFreightRailroadCar.getSecurityInformation());
        System.out.println("Has side doors: " + heavyFreightRailroadCar.isHasSideDoors());
        System.out.println("Brake system: " + heavyFreightRailroadCar.getBrakeSystem() + "\n");
    }

    private void displayRefrigeratedCarDetails(RefrigeratedRailroadCar refrigeratedRailroadCar) {
        System.out.println("Net weight: " + (int) refrigeratedRailroadCar.getNetWeight() + " kg");
        System.out.println("Gross weight: " + (int) refrigeratedRailroadCar.getGrossWeight() + " kg");
        System.out.println("Shipper: " + refrigeratedRailroadCar.getShipper());
        System.out.println("Security information: " + refrigeratedRailroadCar.getSecurityInformation());
        System.out.println("Cargo capacity: " + refrigeratedRailroadCar.getCargoCapacity());
        System.out.println("Has ventilation system: " + refrigeratedRailroadCar.isHasVentilationSystem());
        System.out.println("Temperature min range: " + refrigeratedRailroadCar.getTemperatureMinRange());
        System.out.println("Temperature max range: " + refrigeratedRailroadCar.getTemperatureMaxRange());
        System.out.println("Has humidity control: " + refrigeratedRailroadCar.isHasHumidityControl());
        System.out.println("Is connected to grid: " + refrigeratedRailroadCar.isConnected() + "\n");
    }

    private void displayLiquidMaterialsCarDetails(LiquidMaterialsRailroadCar liquidMaterialsRailroadCar) {
        System.out.println("Net weight: " + (int) liquidMaterialsRailroadCar.getNetWeight() + " kg");
        System.out.println("Gross weight: " + (int) liquidMaterialsRailroadCar.getGrossWeight() + " kg");
        System.out.println("Shipper: " + liquidMaterialsRailroadCar.getShipper());
        System.out.println("Security information: " + liquidMaterialsRailroadCar.getSecurityInformation());
        System.out.println("Cargo capacity: " + liquidMaterialsRailroadCar.getCargoCapacity());
        System.out.println("Has ventilation system: " + liquidMaterialsRailroadCar.isHasVentilationSystem());
        System.out.println("Pump type: " + liquidMaterialsRailroadCar.getPumpType());
        System.out.println("Tank material: " + liquidMaterialsRailroadCar.getTankMaterial() + "\n");
    }

    private void displayGaseousMaterialsCarDetails(GaseousMaterialsRailroadCar gaseousMaterialsRailroadCar) {
        System.out.println("Net weight: " + (int) gaseousMaterialsRailroadCar.getNetWeight() + " kg");
        System.out.println("Gross weight: " + (int) gaseousMaterialsRailroadCar.getGrossWeight() + " kg");
        System.out.println("Shipper: " + gaseousMaterialsRailroadCar.getShipper());
        System.out.println("Security information: " + gaseousMaterialsRailroadCar.getSecurityInformation());
        System.out.println("Cargo capacity: " + gaseousMaterialsRailroadCar.getCargoCapacity());
        System.out.println("Has ventilation system: " + gaseousMaterialsRailroadCar.isHasVentilationSystem());
        System.out.println("Has pressure vessel: " + gaseousMaterialsRailroadCar.isHasPressureVessel());
        System.out.println("Gas type: " + gaseousMaterialsRailroadCar.getGasType() + "\n");
    }

    private void displayExplosivesCarDetails(ExplosivesRailroadCar explosivesRailroadCar) {
        System.out.println("Net weight: " + (int) explosivesRailroadCar.getNetWeight() + " kg");
        System.out.println("Gross weight: " + (int) explosivesRailroadCar.getGrossWeight() + " kg");
        System.out.println("Shipper: " + explosivesRailroadCar.getShipper());
        System.out.println("Security information: " + explosivesRailroadCar.getSecurityInformation());
        System.out.println("Has side doors: " + explosivesRailroadCar.isHasSideDoors());
        System.out.println("Brake system: " + explosivesRailroadCar.getBrakeSystem());
        System.out.println("Explosive type: " + explosivesRailroadCar.getExplosiveType());
        System.out.println("Locking mechanism: " + explosivesRailroadCar.getLockingMechanism() + "\n");
    }

    private void displayToxicMaterialsCarDetails(ToxicMaterialsRailroadCar toxicMaterialsRailroadCar) {
        System.out.println("Net weight: " + (int) toxicMaterialsRailroadCar.getNetWeight() + " kg");
        System.out.println("Gross weight: " + (int) toxicMaterialsRailroadCar.getGrossWeight() + " kg");
        System.out.println("Shipper: " + toxicMaterialsRailroadCar.getShipper());
        System.out.println("Security information: " + toxicMaterialsRailroadCar.getSecurityInformation());
        System.out.println("Has side doors: " + toxicMaterialsRailroadCar.isHasSideDoors());
        System.out.println("Brake system: " + toxicMaterialsRailroadCar.getBrakeSystem());
        System.out.println("Has warning labels: " + toxicMaterialsRailroadCar.isHasWarningLabels());
        System.out.println("Hazmat suit required type: " + toxicMaterialsRailroadCar.getHazmatSuit() + "\n");
    }

    private void displayLiquidToxicMaterialCarDetails(LiquidToxicMaterialRailroadCar liquidToxicMaterialRailroadCar) {
        System.out.println("Net weight: " + (int) liquidToxicMaterialRailroadCar.getNetWeight() + " kg");
        System.out.println("Gross weight: " + (int) liquidToxicMaterialRailroadCar.getGrossWeight() + " kg");
        System.out.println("Shipper: " + liquidToxicMaterialRailroadCar.getShipper());
        System.out.println("Security information: " + liquidToxicMaterialRailroadCar.getShipper());
        System.out.println("Has side doors: " + liquidToxicMaterialRailroadCar.isHasSideDoors());
        System.out.println("Brake system: " + liquidToxicMaterialRailroadCar.getBrakeSystem());
        System.out.println("Has warning labels: " + liquidToxicMaterialRailroadCar.isHasSideDoors());
        System.out.println("Hazmat suit required type: " + liquidToxicMaterialRailroadCar.getBrakeSystem());
        System.out.println("Pump type: " + liquidToxicMaterialRailroadCar.getPumpType());
        System.out.println("Tank material: " + liquidToxicMaterialRailroadCar.getTankMaterial());
        System.out.println("Is expensive: " + liquidToxicMaterialRailroadCar.isExpensive());
        System.out.println("Has cargo tracking system: " + liquidToxicMaterialRailroadCar.isHasCargoTracking() + "\n");
    }
*/

}
