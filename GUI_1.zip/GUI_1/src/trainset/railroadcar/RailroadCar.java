package trainset.railroadcar;

import trainset.Trainset;

public abstract class RailroadCar {
    private static int nextId = 1000;
   private double netWeight;
   private double grossWeight;
   private final int id;
   private Trainset trainset;
   public abstract String getType();

    public RailroadCar(double netWeight, double grossWeight) {
        this.netWeight = netWeight;
        this.grossWeight = grossWeight;
        this.id = uniqueId();
    }

    private static int uniqueId() {
        return nextId++;
    }

    public double getNetWeight() {
        return netWeight;
    }

    public void setNetWeight(double netWeight) {
        this.netWeight = netWeight;
    }

    public double getGrossWeight() {
        return grossWeight;
    }

    public void setGrossWeight(double grossWeight) {
        this.grossWeight = grossWeight;
    }

    public int getId() {
        return id;
    }

    public void setTrainset (Trainset trainset) {
        this.trainset = trainset;
    }

    public Trainset getTrainset() {
        return trainset;
    }

    @Override
    public String toString() {
        return
                "Id: " + id +
                "\nNet weight: " + netWeight +
                "\nGross weight: " + grossWeight;
    }
}
