package trainset.railroadcar.restaurant;

import trainset.railroadcar.ElectricalGrid;
import trainset.railroadcar.RailroadCar;

public class RestaurantRailroadCar extends RailroadCar implements ElectricalGrid, ServeFood, ServeDrink {
    private int numberOfTables;
    private int seatingCapacity;
    private boolean hasBar;
    private CuisineType cuisineType;
    private boolean isConnectedToGrid;

    public RestaurantRailroadCar(double netWeight, double grossWeight, int numberOfTables, int seatingCapacity, boolean hasBar, CuisineType cuisineType, boolean isConnectedToGrid) {
        super(netWeight, grossWeight);
        this.numberOfTables = numberOfTables;
        this.seatingCapacity = seatingCapacity;
        this.hasBar = hasBar;
        this.cuisineType = cuisineType;
        this.isConnectedToGrid = isConnectedToGrid;
    }

    public int getNumberOfTables() {
        return numberOfTables;
    }

    public void setNumberOfTables(int numberOfTables) {
        this.numberOfTables = numberOfTables;
    }

    public int getSeatingCapacity() {
        return seatingCapacity;
    }

    public void setSeatingCapacity(int seatingCapacity) {
        this.seatingCapacity = seatingCapacity;
    }

    public boolean isHasBar() {
        return hasBar;
    }

    public void setHasBar(boolean hasBar) {
        this.hasBar = hasBar;
    }

    public CuisineType getCuisineType() {
        return cuisineType;
    }

    public void setCuisineType(CuisineType cuisineType) {
        this.cuisineType = cuisineType;
    }

    @Override
    public void connect() {
        isConnectedToGrid = true;
    }

    @Override
    public void disconnect() {
        isConnectedToGrid = false;
    }

    @Override
    public boolean isConnected() {
        return isConnectedToGrid;
    }

    @Override
    public void changeConnection() {
        if (isConnectedToGrid) {
            disconnect();
            System.out.println("Railroad car is now disconnected from the electrical grid");
        } else {
            connect();
            System.out.println("Railroad car is now connected to the electrical grid");
        }
    }


    @Override
    public String getType() {
        return "Restaurant car";
    }

    @Override
    public void serveDrink() {
        if (hasBar) {
            System.out.println("Serving a drink...");
        } else {
            System.out.println("This restaurant car does not have a bar");
        }
    }

    @Override
    public void serveFood() {
        System.out.println("Serving food...");
    }
}
