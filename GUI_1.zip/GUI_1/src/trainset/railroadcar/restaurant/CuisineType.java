package trainset.railroadcar.restaurant;

public enum CuisineType {
    POLISH,
    JAPANESE,
    THAI,
    ITALIAN,
    FRENCH,
    MEXICAN,
    OTHER
}
