package trainset.railroadcar.restaurant;

public interface ServeFood {
    void serveFood();
}
