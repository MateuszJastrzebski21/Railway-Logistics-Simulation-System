package trainset.railroadcar.restaurant;

public interface ServeDrink {
    void serveDrink();
}
