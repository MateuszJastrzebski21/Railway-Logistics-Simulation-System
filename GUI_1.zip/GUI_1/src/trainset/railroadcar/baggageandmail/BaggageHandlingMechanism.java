package trainset.railroadcar.baggageandmail;

public enum BaggageHandlingMechanism {
    ROBOTIC,
    CONVEYOR,
    MANUAL
}
