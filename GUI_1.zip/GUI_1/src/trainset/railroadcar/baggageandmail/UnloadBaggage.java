package trainset.railroadcar.baggageandmail;

public interface UnloadBaggage {
    void unloadBaggage();
}
