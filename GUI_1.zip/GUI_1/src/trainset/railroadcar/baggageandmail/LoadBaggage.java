package trainset.railroadcar.baggageandmail;

public interface LoadBaggage {
    void loadBaggage();
}
