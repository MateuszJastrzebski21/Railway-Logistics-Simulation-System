package trainset.railroadcar.baggageandmail;

import trainset.railroadcar.RailroadCar;

public class BaggageAndMailRailroadCar extends RailroadCar implements LoadBaggage, UnloadBaggage {
    private int maxBaggageItems;
    private BaggageHandlingMechanism baggageHandlingMechanism;

    public BaggageAndMailRailroadCar(double netWeight, double grossWeight, int maxBaggageItems, BaggageHandlingMechanism baggageHandlingMechanism) {
        super(netWeight, grossWeight);
        this.maxBaggageItems = maxBaggageItems;
        this.baggageHandlingMechanism = baggageHandlingMechanism;
    }

    public int getMaxBaggageItems() {
        return maxBaggageItems;
    }

    public void setMaxBaggageItems(int maxBaggageItems) {
        this.maxBaggageItems = maxBaggageItems;
    }

    public BaggageHandlingMechanism getBaggageHandlingMechanism() {
        return baggageHandlingMechanism;
    }

    public void setBaggageHandlingMechanism(BaggageHandlingMechanism baggageHandlingMechanism) {
        this.baggageHandlingMechanism = baggageHandlingMechanism;
    }

    @Override
    public String getType() {
        return "Baggage and mail car";
    }

    @Override
    public void loadBaggage() {
        System.out.println("Loading baggage...");
    }

    @Override
    public void unloadBaggage() {
        System.out.println("Unloading baggage...");
    }
}
