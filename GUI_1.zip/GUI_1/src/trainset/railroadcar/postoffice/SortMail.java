package trainset.railroadcar.postoffice;

public interface SortMail {
    void sortMail();
}
