package trainset.railroadcar.postoffice;
import trainset.railroadcar.ElectricalGrid;
import trainset.railroadcar.RailroadCar;

public class PostOfficeRailroad extends RailroadCar implements ElectricalGrid, SortMail, DeliverMail {
    private int numberOfMailSlots;
    private boolean hasSortingMachine;
    private boolean isConnectedToGrid;

    public PostOfficeRailroad(double netWeight, double grossWeight, int numberOfMailSlots, boolean hasSortingMachine, boolean isConnectedToGrid) {
        super(netWeight, grossWeight);
        this.numberOfMailSlots = numberOfMailSlots;
        this.hasSortingMachine = hasSortingMachine;
        this.isConnectedToGrid = isConnectedToGrid;
    }

    public int getNumberOfMailSlots() {
        return numberOfMailSlots;
    }

    public void setNumberOfMailSlots(int numberOfMailSlots) {
        this.numberOfMailSlots = numberOfMailSlots;
    }

    public boolean isHasSortingMachine() {
        return hasSortingMachine;
    }

    public void setHasSortingMachine(boolean hasSortingMachine) {
        this.hasSortingMachine = hasSortingMachine;
    }

    @Override
    public void connect() {
        isConnectedToGrid = true;
    }

    @Override
    public void disconnect() {
        isConnectedToGrid = false;
    }

    @Override
    public boolean isConnected() {
        return isConnectedToGrid;
    }

    @Override
    public void changeConnection() {
        if (isConnectedToGrid) {
            disconnect();
            System.out.println("Railroad car is now disconnected from the electrical grid");
        } else {
            connect();
            System.out.println("Railroad car is now connected to the electrical grid");
        }
    }

    @Override
    public String getType() {
        return "Post office car";
    }

    @Override
    public void deliverMail() {
        System.out.println("Delivering mail...");
    }

    @Override
    public void sortMail() {
        if (hasSortingMachine) {
            System.out.println("Sorting mails using sorting machine...");
        } else {
            System.out.println("Sorting mail manually...");
        }
    }
}
