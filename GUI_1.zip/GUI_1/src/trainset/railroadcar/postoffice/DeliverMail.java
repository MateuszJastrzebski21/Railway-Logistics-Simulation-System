package trainset.railroadcar.postoffice;

public interface DeliverMail {
    void deliverMail();
}
