package trainset.railroadcar;

public interface ElectricalGrid {
    void connect();
    void disconnect();
    boolean isConnected();
    void changeConnection();
}
