package trainset.railroadcar.passenger;

public enum SeatType {
    FIRST_CLASS,
    BUSINESS_CLASS,
    ECONOMY_CLASS,
}
