package trainset.railroadcar.passenger;

public interface AdjustLights {
    void adjustLights();
}
