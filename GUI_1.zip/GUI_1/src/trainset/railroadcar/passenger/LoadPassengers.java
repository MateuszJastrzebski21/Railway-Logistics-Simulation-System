package trainset.railroadcar.passenger;

public interface LoadPassengers {
    void loadPassengers(int passengers);
}
