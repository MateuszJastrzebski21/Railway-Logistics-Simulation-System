package trainset.railroadcar.passenger;
import trainset.railroadcar.ElectricalGrid;
import trainset.railroadcar.RailroadCar;

public class PassengerRailroadCar extends RailroadCar implements ElectricalGrid, LoadPassengers, UnloadPassengers, AdjustLights {
    private int numberOfPassengers;
    private int numberOfSeats;
    private SeatType seatType;
    private boolean isConnectedToGrid;
    private boolean lightOn;

    public PassengerRailroadCar(double netWeight, double grossWeight, int numberOfPassengers, int numberOfSeats, SeatType seatType, boolean isConnectedToGrid) {
        super(netWeight, grossWeight);
        this.numberOfPassengers = numberOfPassengers;
        this.numberOfSeats = numberOfSeats;
        this.seatType = seatType;
        this.isConnectedToGrid = isConnectedToGrid;
        this.lightOn = false;
    }

    public int getNumberOfPassengers() {
        return numberOfPassengers;
    }

    public int getNumberOfSeats() {
        return numberOfSeats;
    }

    public void setNumberOfSeats(int numberOfSeats) {
        this.numberOfSeats = numberOfSeats;
    }

    public SeatType getSeatType() {
        return seatType;
    }

    public void setSeatType(SeatType seatType) {
        this.seatType = seatType;
    }

    @Override
    public void connect() {
        isConnectedToGrid = true;
    }

    @Override
    public void disconnect() {
        isConnectedToGrid = false;
    }

    @Override
    public boolean isConnected() {
        return isConnectedToGrid;
    }

    @Override
    public void changeConnection() {
        if (isConnectedToGrid) {
            disconnect();
            System.out.println("Railroad car is now disconnected from the electrical grid");
        } else {
            connect();
            System.out.println("Railroad car is now connected to the electrical grid");
        }
    }

    @Override
    public void adjustLights() {
        if (isConnectedToGrid) {
            if(lightOn) {
                System.out.println("Turning off the lights.");
                lightOn = false;
            }
            else {
                System.out.println("Turning on the lights.");
                lightOn = true;
            }
        }
        else {
            System.out.println("Cannot adjust lights. The railroad car is not connected to the electrical grid.");
        }
    }

    @Override
    public void loadPassengers(int passengers) {
        if (passengers < 0) {
            System.out.println("Cannot load a negative number of passengers.");
            return;
        }
        int avaibleSeats = numberOfSeats - numberOfPassengers;
        if (passengers > avaibleSeats) {
            System.out.println("Not enough available seats. Loading only " + avaibleSeats);
            numberOfPassengers = numberOfSeats;
        }
        else {
            numberOfPassengers += passengers;
            System.out.println("Loaded " + passengers + " passengers. Total passengers: " + numberOfPassengers);
        }
    }

    @Override
    public void unloadPassengers(int passengers) {
        if (passengers < 0) {
            System.out.println("Cannot unload a negative number of passengers.");
            return;
        }
        if (passengers > numberOfPassengers) {
            System.out.println("Not enough passengers on board. Unloading all " + numberOfPassengers + " passengers.");
            numberOfPassengers = 0;
        }
        else {
            numberOfPassengers -= passengers;
            System.out.println("Unloaded " + passengers + " passengers. Remaining passengers: " + numberOfPassengers);
        }
    }


    @Override
    public String getType() {
        return "Passenger car";
    }
}
