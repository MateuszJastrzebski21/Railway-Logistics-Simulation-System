package trainset.railroadcar.passenger;

public interface UnloadPassengers {
    void unloadPassengers(int passengers);
}
