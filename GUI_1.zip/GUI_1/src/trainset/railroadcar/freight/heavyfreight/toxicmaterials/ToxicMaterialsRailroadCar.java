package trainset.railroadcar.freight.heavyfreight.toxicmaterials;

import trainset.railroadcar.freight.SecurityInformation;
import trainset.railroadcar.freight.Shipper;
import trainset.railroadcar.freight.heavyfreight.BrakeSystem;
import trainset.railroadcar.freight.heavyfreight.HeavyFreightRailroadCar;

public class ToxicMaterialsRailroadCar extends HeavyFreightRailroadCar implements Decontaminate, DisplayWarnings {
    private boolean hasWarningLabels;
    private HazmatSuit hazmatSuit;

    public ToxicMaterialsRailroadCar(double netWeight, double grossWeight, Shipper shipper, SecurityInformation securityInformation, boolean hasSideDoors, BrakeSystem brakeSystem, boolean hasWarningLabels, HazmatSuit hazmatSuit) {
        super(netWeight, grossWeight, shipper, securityInformation, hasSideDoors, brakeSystem);
        this.hasWarningLabels = hasWarningLabels;
        this.hazmatSuit = hazmatSuit;
    }

    public boolean isHasWarningLabels() {
        return hasWarningLabels;
    }

    public void setHasWarningLabels(boolean hasWarningLabels) {
        this.hasWarningLabels = hasWarningLabels;
    }

    public HazmatSuit getHazmatSuit() {
        return hazmatSuit;
    }

    public void setHazmatSuit(HazmatSuit hazmatSuit) {
        this.hazmatSuit = hazmatSuit;
    }

    @Override
    public String getType() {
        return "Toxic material car";
    }

    @Override
    public void decontaminate() {
        System.out.println("Decontaminating...");
    }

    @Override
    public void displayWarnings() {
        if (hasWarningLabels) {
            System.out.println("Displaying warnings...");
        } else {
            System.out.println("This car does not have warning labels");
        }
    }
}
