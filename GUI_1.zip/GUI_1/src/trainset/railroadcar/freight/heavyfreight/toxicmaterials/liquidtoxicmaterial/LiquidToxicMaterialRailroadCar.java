package trainset.railroadcar.freight.heavyfreight.toxicmaterials.liquidtoxicmaterial;

import trainset.railroadcar.freight.SecurityInformation;
import trainset.railroadcar.freight.Shipper;
import trainset.railroadcar.freight.basicfreight.LoadCargo;
import trainset.railroadcar.freight.basicfreight.UnloadCargo;
import trainset.railroadcar.freight.basicfreight.liquidmaterials.AnalyzeChemicalComposition;
import trainset.railroadcar.freight.basicfreight.liquidmaterials.CorrosionMonitor;
import trainset.railroadcar.freight.basicfreight.liquidmaterials.PumpType;
import trainset.railroadcar.freight.basicfreight.liquidmaterials.TankMaterial;
import trainset.railroadcar.freight.heavyfreight.BrakeSystem;
import trainset.railroadcar.freight.heavyfreight.toxicmaterials.HazmatSuit;
import trainset.railroadcar.freight.heavyfreight.toxicmaterials.ToxicMaterialsRailroadCar;

public class LiquidToxicMaterialRailroadCar extends ToxicMaterialsRailroadCar implements AnalyzeChemicalComposition, CorrosionMonitor, TrackCargo, ControlPh {
    PumpType pumpType;
    TankMaterial tankMaterial;
    private boolean isExpensive;
    private boolean hasCargoTracking;

    public LiquidToxicMaterialRailroadCar(double netWeight, double grossWeight, Shipper shipper, SecurityInformation securityInformation, boolean hasSideDoors, BrakeSystem brakeSystem, boolean hasWarningLabels, HazmatSuit hazmatSuit, PumpType pumpType, TankMaterial tankMaterial, boolean isExpensive, boolean hasCargoTracking) {
        super(netWeight, grossWeight, shipper, securityInformation, hasSideDoors, brakeSystem, hasWarningLabels, hazmatSuit);
        this.pumpType = pumpType;
        this.tankMaterial = tankMaterial;
        this.isExpensive = isExpensive;
        this.hasCargoTracking = hasCargoTracking;
    }

    public PumpType getPumpType() {
        return pumpType;
    }

    public void setPumpType(PumpType pumpType) {
        this.pumpType = pumpType;
    }

    public TankMaterial getTankMaterial() {
        return tankMaterial;
    }

    public void setTankMaterial(TankMaterial tankMaterial) {
        this.tankMaterial = tankMaterial;
    }

    public boolean isExpensive() {
        return isExpensive;
    }

    public void setExpensive(boolean expensive) {
        isExpensive = expensive;
    }

    public boolean isHasCargoTracking() {
        return hasCargoTracking;
    }

    public void setHasCargoTracking(boolean hasCargoTracking) {
        this.hasCargoTracking = hasCargoTracking;
    }

    @Override
    public String getType() {
        return "Liquid toxic material car";
    }


    @Override
    public void analyzeChemicalComposition() {
        System.out.println("Analyzing chemical composition...");
    }

    @Override
    public void corrosionMonitor() {
        System.out.println("Monitoring for corrosion...");
    }

    @Override
    public void controlPh() {
        System.out.println("Controlling Ph...");
    }

    @Override
    public void trackCargo() {
        System.out.println("Tracking cargo...");
    }
}
