package trainset.railroadcar.freight.heavyfreight.toxicmaterials.liquidtoxicmaterial;

public interface ControlPh {
    void controlPh();
}
