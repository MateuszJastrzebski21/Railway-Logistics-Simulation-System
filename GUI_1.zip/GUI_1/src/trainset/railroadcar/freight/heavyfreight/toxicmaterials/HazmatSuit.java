package trainset.railroadcar.freight.heavyfreight.toxicmaterials;

public enum HazmatSuit {
    FULL_BODY_SUIT,
    RESPIRATOR,
    GLOVES,
    BOOTS,
    FACE_SHIELD,
    NONE
}
