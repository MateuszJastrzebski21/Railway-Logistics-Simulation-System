package trainset.railroadcar.freight.heavyfreight.toxicmaterials;

public interface DisplayWarnings {
    void displayWarnings();
}
