package trainset.railroadcar.freight.heavyfreight.toxicmaterials;

public interface Decontaminate {
    void decontaminate();
}
