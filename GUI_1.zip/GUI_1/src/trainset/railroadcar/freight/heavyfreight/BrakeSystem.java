package trainset.railroadcar.freight.heavyfreight;

public enum BrakeSystem {
    AIR,
    HYDRAULIC,
    MECHANICAL,
    ELECTRONIC,
    OTHER
}
