package trainset.railroadcar.freight.heavyfreight;

public interface CleanCargoArea {
    void cleanCargoArea();
}
