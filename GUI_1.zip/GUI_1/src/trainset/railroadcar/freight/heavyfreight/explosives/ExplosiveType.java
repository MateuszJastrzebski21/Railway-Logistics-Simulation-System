package trainset.railroadcar.freight.heavyfreight.explosives;

public enum ExplosiveType {
    TNT,
    DYNAMITE,
    C4,
    NITROGLYCERIN,
    FLARES,
    FIREWORKS,
    OTHER
}
