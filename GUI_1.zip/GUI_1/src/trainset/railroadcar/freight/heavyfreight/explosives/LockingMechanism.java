package trainset.railroadcar.freight.heavyfreight.explosives;

public enum LockingMechanism {
    KEY_LOCK,
    PADLOCK,
    ELECTRONIC_LOCK,
    CHAIN_LOCK,
    OTHER
}
