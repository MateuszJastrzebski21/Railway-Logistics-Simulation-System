package trainset.railroadcar.freight.heavyfreight.explosives;

import trainset.railroadcar.freight.SecurityInformation;
import trainset.railroadcar.freight.Shipper;
import trainset.railroadcar.freight.heavyfreight.BrakeSystem;
import trainset.railroadcar.freight.heavyfreight.HeavyFreightRailroadCar;

public class ExplosivesRailroadCar extends HeavyFreightRailroadCar implements Detonate, ExplosivesEmergency{
    private ExplosiveType explosiveType;
    private LockingMechanism lockingMechanism;

    public ExplosivesRailroadCar(double netWeight, double grossWeight, Shipper shipper, SecurityInformation securityInformation, boolean hasSideDoors, BrakeSystem brakeSystem, ExplosiveType explosiveType, LockingMechanism lockingMechanism) {
        super(netWeight, grossWeight, shipper, securityInformation, hasSideDoors, brakeSystem);
        this.explosiveType = explosiveType;
        this.lockingMechanism = lockingMechanism;
    }

    public ExplosiveType getExplosiveType() {
        return explosiveType;
    }

    public void setExplosiveType(ExplosiveType explosiveType) {
        this.explosiveType = explosiveType;
    }

    public LockingMechanism getLockingMechanism() {
        return lockingMechanism;
    }

    public void setLockingMechanism(LockingMechanism lockingMechanism) {
        this.lockingMechanism = lockingMechanism;
    }

    @Override
    public String getType() {
        return "Explosives car";
    }

    @Override
    public void detonate() {
        System.out.println("BOOOOOOM!!!");
    }

    @Override
    public void explosivesEmergency() {
        System.out.println("Evacuating area...");
    }
}
