package trainset.railroadcar.freight.heavyfreight.explosives;

public interface Detonate {
    void detonate();
}
