package trainset.railroadcar.freight.heavyfreight.explosives;

public interface ExplosivesEmergency {
    void explosivesEmergency();
}
