package trainset.railroadcar.freight.heavyfreight;

import trainset.railroadcar.freight.FreightRailroadCar;
import trainset.railroadcar.freight.SecurityInformation;
import trainset.railroadcar.freight.Shipper;

public class HeavyFreightRailroadCar extends FreightRailroadCar implements CleanCargoArea, InspectTheCargo{
    private boolean hasSideDoors;
    private BrakeSystem brakeSystem;

    public HeavyFreightRailroadCar(double netWeight, double grossWeight, Shipper shipper, SecurityInformation securityInformation, boolean hasSideDoors, BrakeSystem brakeSystem) {
        super(netWeight, grossWeight, shipper, securityInformation);
        this.hasSideDoors = hasSideDoors;
        this.brakeSystem = brakeSystem;
    }

    public boolean isHasSideDoors() {
        return hasSideDoors;
    }

    public void setHasSideDoors(boolean hasSideDoors) {
        this.hasSideDoors = hasSideDoors;
    }

    public BrakeSystem getBrakeSystem() {
        return brakeSystem;
    }

    public void setBrakeSystem(BrakeSystem brakeSystem) {
        this.brakeSystem = brakeSystem;
    }

    @Override
    public String getType() {
        return "Heavy freight car";
    }

    @Override
    public void cleanCargoArea() {
        System.out.println("Cleaning cargo area...");
    }

    @Override
    public void inspectTheCargo() {
        if (hasSideDoors) {
            System.out.println("Opening the side doors and inspecting the cargo");
        } else {
            System.out.println("Inspecting the cargo from top");
        }
    }
}
