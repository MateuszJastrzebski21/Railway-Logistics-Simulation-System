package trainset.railroadcar.freight.heavyfreight;

public interface InspectTheCargo {
    void inspectTheCargo();
}
