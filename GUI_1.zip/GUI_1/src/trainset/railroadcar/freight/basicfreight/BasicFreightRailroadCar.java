package trainset.railroadcar.freight.basicfreight;

import trainset.railroadcar.baggageandmail.UnloadBaggage;
import trainset.railroadcar.freight.FreightRailroadCar;
import trainset.railroadcar.freight.SecurityInformation;
import trainset.railroadcar.freight.Shipper;

public class BasicFreightRailroadCar extends FreightRailroadCar implements LoadCargo, UnloadCargo {
    private int cargoCapacity; // in cubic meters
    private boolean hasVentilationSystem;

    public BasicFreightRailroadCar(double netWeight, double grossWeight, Shipper shipper, SecurityInformation securityInformation, int cargoCapacity, boolean hasVentilationSystem) {
        super(netWeight, grossWeight, shipper, securityInformation);
        this.cargoCapacity = cargoCapacity;
        this.hasVentilationSystem = hasVentilationSystem;
    }

    public int getCargoCapacity() {
        return cargoCapacity;
    }

    public void setCargoCapacity(int cargoCapacity) {
        this.cargoCapacity = cargoCapacity;
    }

    public boolean isHasVentilationSystem() {
        return hasVentilationSystem;
    }

    public void setHasVentilationSystem(boolean hasVentilationSystem) {
        this.hasVentilationSystem = hasVentilationSystem;
    }

    @Override
    public String getType() {
        return "Basic freight car";
    }

    @Override
    public void loadCargo(int volume) {
        if (volume > cargoCapacity) {
            System.out.println("Not enough capacity for this volume of cargo");
        } else {
            System.out.println("Loading cargo...");
            cargoCapacity -= volume;
        }
    }

    @Override
    public void unloadCargo(int volume) {
        System.out.println("Unloading cargo...");
        cargoCapacity += volume;
    }
}
