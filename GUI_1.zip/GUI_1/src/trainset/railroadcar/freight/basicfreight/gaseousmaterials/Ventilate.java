package trainset.railroadcar.freight.basicfreight.gaseousmaterials;

public interface Ventilate {
    void ventilate();
}
