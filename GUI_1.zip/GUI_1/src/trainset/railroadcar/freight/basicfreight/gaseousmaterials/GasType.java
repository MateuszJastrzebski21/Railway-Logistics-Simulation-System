package trainset.railroadcar.freight.basicfreight.gaseousmaterials;

public enum GasType {
    METHANE,
    ETHANE,
    PROPANE,
    BUTANE,
    OXYGEN,
    HYDROGEN,
    HELIUM,
    CHLORINE,
    OTHER
}
