package trainset.railroadcar.freight.basicfreight.gaseousmaterials;

import trainset.railroadcar.freight.SecurityInformation;
import trainset.railroadcar.freight.Shipper;
import trainset.railroadcar.freight.basicfreight.BasicFreightRailroadCar;

public class GaseousMaterialsRailroadCar extends BasicFreightRailroadCar implements Ventilate, DetectGasLeak{
    private boolean hasPressureVessel;
    private GasType gasType;

    public GaseousMaterialsRailroadCar(double netWeight, double grossWeight, Shipper shipper, SecurityInformation securityInformation, int cargoCapacity, boolean hasVentilationSystem, boolean hasPressureVessel, GasType gasType) {
        super(netWeight, grossWeight, shipper, securityInformation, cargoCapacity, hasVentilationSystem);
        this.hasPressureVessel = hasPressureVessel;
        this.gasType = gasType;
    }

    public boolean isHasPressureVessel() {
        return hasPressureVessel;
    }

    public void setHasPressureVessel(boolean hasPressureVessel) {
        this.hasPressureVessel = hasPressureVessel;
    }

    public GasType getGasType() {
        return gasType;
    }

    public void setGasType(GasType gasType) {
        this.gasType = gasType;
    }

    @Override
    public String getType() {
        return "Gaseous material car";
    }

    @Override
    public void detectGasLeak() {
        System.out.println("Detecting gas leaks...");
    }

    @Override
    public void ventilate() {
        System.out.println("Ventilating...");
    }
}
