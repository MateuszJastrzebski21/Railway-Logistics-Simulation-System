package trainset.railroadcar.freight.basicfreight.gaseousmaterials;

public interface DetectGasLeak {
    void detectGasLeak();
}
