package trainset.railroadcar.freight.basicfreight.refrigerated;

public interface LowerTemperature {
    void lowerTemperature(int change);
}
