package trainset.railroadcar.freight.basicfreight.refrigerated;

import trainset.railroadcar.ElectricalGrid;
import trainset.railroadcar.freight.SecurityInformation;
import trainset.railroadcar.freight.Shipper;
import trainset.railroadcar.freight.basicfreight.BasicFreightRailroadCar;
import trainset.railroadcar.freight.basicfreight.LoadCargo;
import trainset.railroadcar.freight.basicfreight.UnloadCargo;

public class RefrigeratedRailroadCar extends BasicFreightRailroadCar implements ElectricalGrid, LowerTemperature, IncreaseTemperature {
    private int temperatureMinRange;
    private int temperatureMaxRange;
    private boolean hasHumidityControl;
    private boolean isConnectedToGrid;

    public RefrigeratedRailroadCar(double netWeight, double grossWeight, Shipper shipper, SecurityInformation securityInformation, int cargoCapacity, boolean hasVentilationSystem, int temperatureMinRange, int temperatureMaxRange, boolean hasHumidityControl, boolean isConnectedToGrid) {
        super(netWeight, grossWeight, shipper, securityInformation, cargoCapacity, hasVentilationSystem);
        this.temperatureMinRange = temperatureMinRange;
        this.temperatureMaxRange = temperatureMaxRange;
        this.hasHumidityControl = hasHumidityControl;
        this.isConnectedToGrid = isConnectedToGrid;
    }

    public int getTemperatureMinRange() {
        return temperatureMinRange;
    }

    public void setTemperatureMinRange(int temperatureMinRange) {
        this.temperatureMinRange = temperatureMinRange;
    }

    public int getTemperatureMaxRange() {
        return temperatureMaxRange;
    }

    public void setTemperatureMaxRange(int temperatureMaxRange) {
        this.temperatureMaxRange = temperatureMaxRange;
    }

    public boolean isHasHumidityControl() {
        return hasHumidityControl;
    }

    public void setHasHumidityControl(boolean hasHumidityControl) {
        this.hasHumidityControl = hasHumidityControl;
    }

    @Override
    public void connect() {
        isConnectedToGrid = true;
    }

    @Override
    public void disconnect() {
        isConnectedToGrid = false;
    }

    @Override
    public boolean isConnected() {
        return isConnectedToGrid;
    }

    @Override
    public void changeConnection() {
        if (isConnectedToGrid) {
            disconnect();
            System.out.println("Railroad car is now disconnected from the electrical grid");
        } else {
            connect();
            System.out.println("Railroad car is now connected to the electrical grid");
        }
    }

    @Override
    public String getType() {
        return "Refrigerated Car";
    }

    @Override
    public void increseTemperature(int change) {
        System.out.println("Increasing the temperature by " + change + " degrees Celcius...");
        temperatureMinRange += change;
        temperatureMaxRange += change;
    }

    @Override
    public void lowerTemperature(int change) {
        System.out.println("Lowering the temperature by " + change + " degrees Celcius...");
        temperatureMinRange -= change;
        temperatureMaxRange -= change;
    }
}
