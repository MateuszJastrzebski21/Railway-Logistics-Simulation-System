package trainset.railroadcar.freight.basicfreight.refrigerated;

public interface IncreaseTemperature {
    void increseTemperature(int change);
}
