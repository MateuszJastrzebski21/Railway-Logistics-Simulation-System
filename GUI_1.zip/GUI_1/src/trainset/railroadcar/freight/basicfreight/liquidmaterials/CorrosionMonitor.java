package trainset.railroadcar.freight.basicfreight.liquidmaterials;

public interface CorrosionMonitor {
    void corrosionMonitor();
}
