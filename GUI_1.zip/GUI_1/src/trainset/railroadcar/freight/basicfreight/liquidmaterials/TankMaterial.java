package trainset.railroadcar.freight.basicfreight.liquidmaterials;

public enum TankMaterial {
    STAINLESS_STEEL,
    ALUMINIUM,
    TITANIUM,
    COPPER,
    PLASTIC,
    RUBBER,
    OTHER
}
