package trainset.railroadcar.freight.basicfreight.liquidmaterials;

public interface AnalyzeChemicalComposition {
    void analyzeChemicalComposition();
}
