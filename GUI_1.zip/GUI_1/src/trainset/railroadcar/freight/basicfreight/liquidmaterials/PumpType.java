package trainset.railroadcar.freight.basicfreight.liquidmaterials;

public enum PumpType {
    PISTON,
    PROPELLER,
    IMPELLER,
    SUBMERSIBLE,
    LOBE,
    OTHER
}
