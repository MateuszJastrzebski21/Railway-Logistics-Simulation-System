package trainset.railroadcar.freight.basicfreight.liquidmaterials;

import trainset.railroadcar.freight.SecurityInformation;
import trainset.railroadcar.freight.Shipper;
import trainset.railroadcar.freight.basicfreight.BasicFreightRailroadCar;

public class LiquidMaterialsRailroadCar extends BasicFreightRailroadCar implements AnalyzeChemicalComposition, CorrosionMonitor{
    private PumpType pumpType;
    private TankMaterial tankMaterial;

    public LiquidMaterialsRailroadCar(double netWeight, double grossWeight, Shipper shipper, SecurityInformation securityInformation, int cargoCapacity, boolean hasVentilationSystem, PumpType pumpType, TankMaterial tankMaterial) {
        super(netWeight, grossWeight, shipper, securityInformation, cargoCapacity, hasVentilationSystem);
        this.pumpType = pumpType;
        this.tankMaterial = tankMaterial;
    }

    public PumpType getPumpType() {
        return pumpType;
    }

    public void setPumpType(PumpType pumpType) {
        this.pumpType = pumpType;
    }

    public TankMaterial getTankMaterial() {
        return tankMaterial;
    }

    public void setTankMaterial(TankMaterial tankMaterial) {
        this.tankMaterial = tankMaterial;
    }

    @Override
    public String getType() {
        return "Liquid material car";
    }

    @Override
    public void analyzeChemicalComposition() {
        System.out.println("Analyzing chemical composition...");
    }

    @Override
    public void corrosionMonitor() {
        System.out.println("Monitoring for corrosion...");
    }
}
