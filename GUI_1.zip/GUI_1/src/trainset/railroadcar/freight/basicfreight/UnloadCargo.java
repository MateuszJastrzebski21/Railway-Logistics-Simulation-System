package trainset.railroadcar.freight.basicfreight;

public interface UnloadCargo {
    void unloadCargo (int volume);
}
