package trainset.railroadcar.freight.basicfreight;

public interface LoadCargo {
    void loadCargo(int volume);
}
