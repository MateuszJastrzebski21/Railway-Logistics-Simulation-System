package trainset.railroadcar.freight;

import trainset.railroadcar.RailroadCar;

public abstract class FreightRailroadCar extends RailroadCar {
    private Shipper shipper;
    private SecurityInformation securityInformation;

    public FreightRailroadCar(double netWeight, double grossWeight, Shipper shipper, SecurityInformation securityInformation) {
        super(netWeight, grossWeight);
        this.shipper = shipper;
        this.securityInformation = securityInformation;
    }

    public Shipper getShipper() {
        return shipper;
    }

    public void setShipper(Shipper shipper) {
        this.shipper = shipper;
    }

    public SecurityInformation getSecurityInformation() {
        return securityInformation;
    }

    public void setSecurityInformation(SecurityInformation securityInformation) {
        this.securityInformation = securityInformation;
    }
}
