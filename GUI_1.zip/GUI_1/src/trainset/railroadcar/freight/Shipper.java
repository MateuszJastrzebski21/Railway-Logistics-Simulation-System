package trainset.railroadcar.freight;

public enum Shipper {
    PKP_CARGO,
    PKP_LHS,
    KOLEJ_MAZOWIECKA,
    LOTOS_KOLEJ,
    KOLPREM,
    CTL_LOGISTICS,
    UNION_PACIFIC,
    BNSF,
    AMTRAK,
    OTHER
}
