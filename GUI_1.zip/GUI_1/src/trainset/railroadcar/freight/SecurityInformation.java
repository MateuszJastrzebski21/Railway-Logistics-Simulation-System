package trainset.railroadcar.freight;

public enum SecurityInformation {
    TOP_SECRET,
    CLASSIFIED,
    CONFIDENTIAL,
    RESTRICTED,
    UNCLASSIFIED
}
