package trainset.locomotive;

import railwaystation.RailwayStation;

import java.util.List;

public class Locomotive {
    private static int nextId = 1000;
    private boolean isAtStation;
    private int maxNumOfCars; // Maximum number of railroad cars
    private int maxWeightOfLoad; // Maximum weight of the transported load
    private int maxNumOfCarsConnected; // The maximum number of railroad cars that need to be connected to the electricity grid
    private String name;
    private RailwayStation homeStation;
    private RailwayStation sourceStation;
    private RailwayStation destinationStation;
    private RailwayStation currentStation;
    private int id;
    private double speed;

    public Locomotive(int maxNumOfCars, int maxWeightOfLoad, int maxNumOfCarsConnected, String name, RailwayStation homeStation, RailwayStation sourceStation, RailwayStation destinationStation, double speed) {
        this.maxNumOfCars = maxNumOfCars;
        this.maxWeightOfLoad = maxWeightOfLoad;
        this.maxNumOfCarsConnected = maxNumOfCarsConnected;
        this.name = name;
        this.homeStation = homeStation;
        this.sourceStation = sourceStation;
        this.destinationStation = destinationStation;
        this.id = uniqueId();
        this.speed = speed;
    }

    private static int uniqueId() {
        return nextId++;
    }

    public static int getNextId() {
        return nextId;
    }

    public int getMaxNumOfCars() {
        return maxNumOfCars;
    }

    public void setMaxNumOfCars(int maxNumOfCars) {
        this.maxNumOfCars = maxNumOfCars;
    }

    public int getMaxWeightOfLoad() {
        return maxWeightOfLoad;
    }

    public void setMaxWeightOfLoad(int maxWeightOfLoad) {
        this.maxWeightOfLoad = maxWeightOfLoad;
    }

    public int getMaxNumOfCarsConnected() {
        return maxNumOfCarsConnected;
    }

    public void setMaxNumOfCarsConnected(int maxNumOfCarsConnected) {
        this.maxNumOfCarsConnected = maxNumOfCarsConnected;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public RailwayStation getHomeStation() {
        return homeStation;
    }

    public void setHomeStation(RailwayStation homeStation) {
        this.homeStation = homeStation;
    }

    public RailwayStation getSourceStation() {
        return sourceStation;
    }

    public void setSourceStation(RailwayStation sourceStation) {
        this.sourceStation = sourceStation;
    }

    public RailwayStation getDestinationStation() {
        return destinationStation;
    }

    public void setDestinationStation(RailwayStation destinationStation) {
        this.destinationStation = destinationStation;
    }

    public int getId() {
        return id;
    }

    public double getSpeed() {
        return speed;
    }

    public void setSpeed(double speed) {
        this.speed = speed;
    }

    public void updateSpeed() {
        double change = 0.03 * speed * (Math.random() * 2 - 1);
        speed += change;
    }

    public RailwayStation getCurrentStation() {
        return currentStation;
    }

    public void setCurrentStation(RailwayStation currentStation) {
        this.currentStation = currentStation;
    }

    public boolean isAtStation() {
        return currentStation != null;
    }

}
